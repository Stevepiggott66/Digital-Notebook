import { and, asc, eq } from "drizzle-orm";
import { requireAccess } from "../../access";
import { canUseCategory } from "../../category-access";
import { getDb } from "../../../db";
import { savedFilters } from "../../../db/schema";

export async function GET() {
  const access = await requireAccess(); if (access.error || !access.user) return access.error;
  const filters = await getDb().select().from(savedFilters).where(eq(savedFilters.userId, access.user.id)).orderBy(asc(savedFilters.name));
  return Response.json({ filters });
}

export async function POST(request: Request) {
  const access = await requireAccess(); if (access.error || !access.user) return access.error;
  const input = await request.json() as { name?: string; status?: string; priority?: string; categoryId?: string | null; dueWindow?: string };
  if (!input.name?.trim()) return Response.json({ error: "Filter name is required" }, { status: 400 });
  if (input.categoryId && !await canUseCategory(access.user, input.categoryId, "VIEWER")) return Response.json({ error: "Category not found" }, { status: 404 });
  const filter = { id: crypto.randomUUID(), name: input.name.trim(), userId: access.user.id, status: input.status || null, priority: input.priority || null, categoryId: input.categoryId || null, dueWindow: input.dueWindow || "all", createdAt: new Date() };
  await getDb().insert(savedFilters).values(filter); return Response.json({ filter }, { status: 201 });
}

export async function DELETE(request: Request) {
  const access = await requireAccess(); if (access.error || !access.user) return access.error;
  const id = new URL(request.url).searchParams.get("id"); if (!id) return Response.json({ error: "Filter id is required" }, { status: 400 });
  await getDb().delete(savedFilters).where(and(eq(savedFilters.id, id), eq(savedFilters.userId, access.user.id)));
  return Response.json({ ok: true });
}
