CREATE TABLE `category_permissions` (
	`category_id` text NOT NULL,
	`allowed_user_id` text NOT NULL,
	`permission` text DEFAULT 'VIEWER' NOT NULL,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	PRIMARY KEY(`category_id`, `allowed_user_id`),
	FOREIGN KEY (`category_id`) REFERENCES `categories`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`allowed_user_id`) REFERENCES `allowed_users`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `category_permissions_user_idx` ON `category_permissions` (`allowed_user_id`);