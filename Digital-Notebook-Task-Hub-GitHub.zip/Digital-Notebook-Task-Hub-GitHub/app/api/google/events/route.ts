import { and, eq } from "drizzle-orm";
import { requireAccess } from "../../../access";
import { googleFetch } from "../../../google";
import { getDb } from "../../../../db";
import { googleCalendars } from "../../../../db/schema";

type EventList = { items?: { id?: string; summary?: string; htmlLink?: string; start?: { date?: string; dateTime?: string }; end?: { date?: string; dateTime?: string } }[] };

export async function GET(request: Request) {
  const access = await requireAccess(); if (access.error || !access.user) return access.error;
  const url = new URL(request.url); const from = url.searchParams.get("from"); const to = url.searchParams.get("to");
  if (!from || !to) return Response.json({ error: "A date range is required" }, { status: 400 });
  const calendars = await getDb().select().from(googleCalendars).where(and(eq(googleCalendars.userId, access.user.id), eq(googleCalendars.enabled, true)));
  try {
    const groups = await Promise.all(calendars.map(async calendar => {
      const endpoint = new URL(`https://www.googleapis.com/calendar/v3/calendars/${encodeURIComponent(calendar.calendarId)}/events`);
      endpoint.search = new URLSearchParams({ timeMin: new Date(from).toISOString(), timeMax: new Date(to).toISOString(), singleEvents: "true", orderBy: "startTime", maxResults: "250" }).toString();
      const response = await googleFetch(access.user.id, request, endpoint.toString()); const payload = await response.json() as EventList;
      if (!response.ok) return [];
      return (payload.items ?? []).map(event => ({ id: `${calendar.calendarId}:${event.id}`, title: event.summary || "Busy", start: event.start?.dateTime || event.start?.date || "", end: event.end?.dateTime || event.end?.date || "", date: event.start?.date || event.start?.dateTime?.slice(0, 10) || "", url: event.htmlLink || null, calendar: calendar.summary, color: calendar.color || "#557f95" }));
    }));
    return Response.json({ events: groups.flat() });
  } catch (error) { return Response.json({ error: error instanceof Error ? error.message : "Unable to load calendar events" }, { status: 409 }); }
}
