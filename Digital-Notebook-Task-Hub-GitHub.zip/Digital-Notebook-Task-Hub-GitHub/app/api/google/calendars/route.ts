import { and, asc, eq, inArray } from "drizzle-orm";
import { requireAccess } from "../../../access";
import { googleFetch } from "../../../google";
import { getDb } from "../../../../db";
import { googleCalendars } from "../../../../db/schema";

type CalendarList = { items?: { id?: string; summary?: string; backgroundColor?: string; primary?: boolean }[]; error?: { message?: string } };

export async function GET(request: Request) {
  const access = await requireAccess(); if (access.error || !access.user) return access.error;
  try {
    const response = await googleFetch(access.user.id, request, "https://www.googleapis.com/calendar/v3/users/me/calendarList?maxResults=250");
    const payload = await response.json() as CalendarList; if (!response.ok) throw new Error(payload.error?.message || "Unable to load Google calendars");
    const db = getDb(); const now = new Date();
    for (const item of payload.items ?? []) if (item.id) await db.insert(googleCalendars).values({ id: crypto.randomUUID(), calendarId: item.id, summary: item.summary || item.id, color: item.backgroundColor || null, enabled: Boolean(item.primary), userId: access.user.id, updatedAt: now }).onConflictDoUpdate({ target: [googleCalendars.userId, googleCalendars.calendarId], set: { summary: item.summary || item.id, color: item.backgroundColor || null, updatedAt: now } });
    const calendars = await db.select().from(googleCalendars).where(eq(googleCalendars.userId, access.user.id)).orderBy(asc(googleCalendars.summary));
    return Response.json({ calendars });
  } catch (error) { return Response.json({ error: error instanceof Error ? error.message : "Unable to load Google calendars" }, { status: 409 }); }
}

export async function PATCH(request: Request) {
  const access = await requireAccess(); if (access.error || !access.user) return access.error;
  const { ids } = await request.json() as { ids?: string[] }; const enabled = [...new Set(ids ?? [])]; const db = getDb();
  await db.update(googleCalendars).set({ enabled: false, updatedAt: new Date() }).where(eq(googleCalendars.userId, access.user.id));
  if (enabled.length) await db.update(googleCalendars).set({ enabled: true, updatedAt: new Date() }).where(and(eq(googleCalendars.userId, access.user.id), inArray(googleCalendars.calendarId, enabled)));
  return Response.json({ ok: true });
}
