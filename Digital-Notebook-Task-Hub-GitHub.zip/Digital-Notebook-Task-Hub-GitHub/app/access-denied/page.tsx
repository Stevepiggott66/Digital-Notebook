import Link from "next/link";

export default function AccessDeniedPage() {
  return <main className="access-denied"><div className="access-denied-card"><span className="brand-mark">d</span><p className="eyebrow">Access pending</p><h1>This notebook is invitation only.</h1><p>Your account is signed in, but an administrator has not approved this email address yet.</p><Link className="primary-button" href="/signout-with-chatgpt?return_to=/login">Sign in with another account</Link></div></main>;
}
