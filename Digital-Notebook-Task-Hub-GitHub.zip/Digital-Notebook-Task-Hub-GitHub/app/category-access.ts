import { and, eq } from "drizzle-orm";
import { getDb } from "../db";
import { allowedUsers, categories, categoryPermissions, tasks } from "../db/schema";
import type { AccessUser } from "./access";

export type CategoryPermission = "VIEWER" | "CONTRIBUTOR" | "MANAGER";

const permissionRank: Record<CategoryPermission, number> = { VIEWER: 1, CONTRIBUTOR: 2, MANAGER: 3 };

export function permissionAllows(actual: CategoryPermission | null, required: CategoryPermission) {
  return Boolean(actual && permissionRank[actual] >= permissionRank[required]);
}

export async function categoryAccessMap(user: AccessUser) {
  const db = getDb();
  if (user.role === "ADMIN") {
    const rows = await db.select({ id: categories.id }).from(categories);
    return new Map(rows.map(row => [row.id, "MANAGER" as CategoryPermission]));
  }
  const rows = await db.select({ categoryId: categoryPermissions.categoryId, permission: categoryPermissions.permission })
    .from(categoryPermissions)
    .innerJoin(allowedUsers, eq(allowedUsers.id, categoryPermissions.allowedUserId))
    .where(and(eq(allowedUsers.email, user.email), eq(allowedUsers.isActive, true)));
  return new Map(rows.map(row => [row.categoryId, row.permission as CategoryPermission]));
}

export async function categoryPermissionFor(user: AccessUser, categoryId: string | null) {
  if (!categoryId) return user.role === "ADMIN" ? "MANAGER" as CategoryPermission : null;
  return (await categoryAccessMap(user)).get(categoryId) ?? null;
}

export async function canUseCategory(user: AccessUser, categoryId: string | null, required: CategoryPermission) {
  return permissionAllows(await categoryPermissionFor(user, categoryId), required);
}

export async function taskPermissionFor(user: AccessUser, taskId: string) {
  const task = (await getDb().select({ id: tasks.id, categoryId: tasks.categoryId }).from(tasks).where(eq(tasks.id, taskId)).limit(1))[0];
  if (!task) return null;
  return categoryPermissionFor(user, task.categoryId);
}

export async function canUseTask(user: AccessUser, taskId: string, required: CategoryPermission) {
  return permissionAllows(await taskPermissionFor(user, taskId), required);
}
