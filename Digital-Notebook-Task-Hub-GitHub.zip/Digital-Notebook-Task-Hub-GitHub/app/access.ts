import { and, count, eq } from "drizzle-orm";
import { getDb } from "../db";
import { allowedUsers, users } from "../db/schema";
import { getChatGPTUser } from "./chatgpt-auth";

export type AccessUser = {
  id: string;
  email: string;
  name: string;
  role: "ADMIN" | "MEMBER";
};

export async function getAccessUser(): Promise<{ identity: Awaited<ReturnType<typeof getChatGPTUser>>; user: AccessUser | null }> {
  const identity = await getChatGPTUser();
  if (!identity) return { identity: null, user: null };
  const email = identity.email.trim().toLowerCase();
  const db = getDb();

  const total = await db.select({ value: count() }).from(allowedUsers);
  if ((total[0]?.value ?? 0) === 0) {
    await db.insert(allowedUsers).values({ id: crypto.randomUUID(), email, role: "ADMIN", isActive: true, createdBy: email, createdAt: new Date() }).onConflictDoNothing();
  }

  const access = await db.select().from(allowedUsers).where(and(eq(allowedUsers.email, email), eq(allowedUsers.isActive, true))).limit(1);
  if (!access[0]) return { identity, user: null };

  const existing = await db.select().from(users).where(eq(users.email, email)).limit(1);
  let userId = existing[0]?.id;
  if (!userId) {
    userId = crypto.randomUUID();
    const now = new Date();
    await db.insert(users).values({ id: userId, email, name: identity.fullName, image: null, googleAccessToken: null, googleRefreshToken: null, createdAt: now, updatedAt: now });
  }

  return { identity, user: { id: userId, email, name: identity.displayName, role: access[0].role } };
}

export async function requireAccess() {
  const access = await getAccessUser();
  if (!access.identity) return { error: Response.json({ error: "Unauthorized" }, { status: 401 }), user: null };
  if (!access.user) return { error: Response.json({ error: "Access not approved" }, { status: 403 }), user: null };
  return { error: null, user: access.user };
}

export async function requireAdmin() {
  const access = await requireAccess();
  if (access.error || !access.user) return access;
  if (access.user.role !== "ADMIN") return { error: Response.json({ error: "Administrator access required" }, { status: 403 }), user: null };
  return access;
}
