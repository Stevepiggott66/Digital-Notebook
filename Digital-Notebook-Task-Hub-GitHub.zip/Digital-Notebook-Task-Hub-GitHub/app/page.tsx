import { redirect } from "next/navigation";
import { getAccessUser } from "./access";
import { Workspace } from "./workspace";

export const dynamic = "force-dynamic";

export default async function Home() {
  const access = await getAccessUser();
  if (!access.identity) redirect("/login");
  if (!access.user) redirect("/access-denied");

  return <Workspace user={{ name: access.user.name, email: access.user.email, isAdmin: access.user.role === "ADMIN" }} />;
}
