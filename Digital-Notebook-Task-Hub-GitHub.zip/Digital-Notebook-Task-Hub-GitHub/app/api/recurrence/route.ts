import { and, desc, eq, gt, inArray, lt, ne } from "drizzle-orm";
import { requireAccess } from "../../access";
import { canUseTask } from "../../category-access";
import { getFileBucket } from "../../file-storage";
import { nextMoment } from "../../recurrence";
import { getDb } from "../../../db";
import { gmailThreads, recurringSeries, taskAttachments, tasks } from "../../../db/schema";

async function taskAndSeries(taskId: string) {
  const db = getDb();
  const task = (await db.select().from(tasks).where(eq(tasks.id, taskId)).limit(1))[0];
  const series = task?.seriesId ? (await db.select().from(recurringSeries).where(eq(recurringSeries.id, task.seriesId)).limit(1))[0] : null;
  return { task, series };
}

async function previousOccurrence(task: typeof tasks.$inferSelect) {
  const db = getDb();
  if (task.previousOccurrenceId) {
    const linked = (await db.select().from(tasks).where(eq(tasks.id, task.previousOccurrenceId)).limit(1))[0];
    if (linked) return linked;
  }
  if (!task.seriesId || !task.occurrenceDate) return null;
  return (await db.select().from(tasks).where(and(eq(tasks.seriesId, task.seriesId), lt(tasks.occurrenceDate, task.occurrenceDate))).orderBy(desc(tasks.occurrenceDate)).limit(1))[0] ?? null;
}

async function removePristineFutureOccurrences(seriesId: string) {
  const db = getDb();
  const future = await db.select().from(tasks).where(and(eq(tasks.seriesId, seriesId), gt(tasks.occurrenceDate, new Date())));
  if (!future.length) return null;
  const ids = future.map(task => task.id);
  const [children, attachments, mail] = await Promise.all([
    db.select({ parentId: tasks.parentId }).from(tasks).where(inArray(tasks.parentId, ids)),
    db.select({ taskId: taskAttachments.taskId }).from(taskAttachments).where(inArray(taskAttachments.taskId, ids)),
    db.select({ taskId: gmailThreads.taskId }).from(gmailThreads).where(inArray(gmailThreads.taskId, ids)),
  ]);
  const protectedIds = new Set([...children.map(item => item.parentId), ...attachments.map(item => item.taskId), ...mail.map(item => item.taskId)]);
  const removable = future.filter(task => task.status === "TODO" && !task.description && task.createdAt.getTime() === task.updatedAt.getTime() && !protectedIds.has(task.id));
  if (!removable.length) return null;
  await db.delete(tasks).where(inArray(tasks.id, removable.map(task => task.id)));
  return removable.reduce((earliest, task) => !earliest || (task.occurrenceDate && task.occurrenceDate < earliest) ? task.occurrenceDate : earliest, null as Date | null);
}

async function copyTaskAttachments(sourceTaskId: string, targetTaskId: string, userId: string) {
  const db = getDb();
  const [source, existing] = await Promise.all([
    db.select().from(taskAttachments).where(eq(taskAttachments.taskId, sourceTaskId)),
    db.select().from(taskAttachments).where(eq(taskAttachments.taskId, targetTaskId)),
  ]);
  if (!source.length) return 0;

  const signature = (item: { fileName: string; contentType: string; size: number }) => `${item.fileName}\u0000${item.contentType}\u0000${item.size}`;
  const existingCounts = new Map<string, number>();
  for (const attachment of existing) {
    const key = signature(attachment);
    existingCounts.set(key, (existingCounts.get(key) ?? 0) + 1);
  }

  const bucket = getFileBucket();
  let copied = 0;
  for (const attachment of source) {
    const key = signature(attachment);
    const matches = existingCounts.get(key) ?? 0;
    if (matches > 0) { existingCounts.set(key, matches - 1); continue; }
    const object = await bucket.get(attachment.storageKey);
    if (!object) continue;
    const id = crypto.randomUUID();
    const storageKey = `${userId}/${targetTaskId}/${id}`;
    await bucket.put(storageKey, object.body, { httpMetadata: { contentType: attachment.contentType }, customMetadata: { fileName: attachment.fileName } });
    try {
      await db.insert(taskAttachments).values({ id, taskId: targetTaskId, storageKey, fileName: attachment.fileName, contentType: attachment.contentType, size: attachment.size, createdAt: new Date() });
    } catch (error) {
      await bucket.delete(storageKey);
      throw error;
    }
    copied += 1;
  }
  return copied;
}

export async function GET(request: Request) {
  const access = await requireAccess();
  if (access.error || !access.user) return access.error;
  const taskId = new URL(request.url).searchParams.get("taskId");
  if (!taskId) return Response.json({ error: "Task id is required" }, { status: 400 });
  if (!await canUseTask(access.user, taskId, "VIEWER")) return Response.json({ error: "Task not found" }, { status: 404 });
  const { task } = await taskAndSeries(taskId);
  if (!task) return Response.json({ error: "Task not found" }, { status: 404 });
  const previous = await previousOccurrence(task);
  if (!previous || !await canUseTask(access.user, previous.id, "VIEWER")) return Response.json({ error: "No previous occurrence exists" }, { status: 404 });
  return Response.json({ previous });
}

export async function POST(request: Request) {
  const access = await requireAccess();
  if (access.error || !access.user) return access.error;
  const input = await request.json() as { taskId?: string; action?: "pause" | "resume" | "delete" | "carry" };
  if (!input.taskId || !input.action) return Response.json({ error: "Task and action are required" }, { status: 400 });
  const required = input.action === "delete" ? "MANAGER" : "CONTRIBUTOR";
  if (!await canUseTask(access.user, input.taskId, required)) return Response.json({ error: `You need ${required === "MANAGER" ? "manager" : "edit"} access for this recurring task` }, { status: 403 });
  const db = getDb();
  const { task, series } = await taskAndSeries(input.taskId);
  if (!task || !series) return Response.json({ error: "Recurring series not found" }, { status: 404 });

  if (input.action === "pause") {
    const earliestRemoved = await removePristineFutureOccurrences(series.id);
    await db.update(recurringSeries).set({ pausedAt: new Date(), ...(earliestRemoved && { nextOccurrenceAt: earliestRemoved }), updatedAt: new Date() }).where(eq(recurringSeries.id, series.id));
    return Response.json({ ok: true, message: "Recurring series paused" });
  }
  if (input.action === "resume") {
    let next = series.nextOccurrenceAt;
    const now = new Date();
    while (next <= now) next = nextMoment(next, series.recurrence);
    await db.update(recurringSeries).set({ pausedAt: null, deletedAt: null, nextOccurrenceAt: next, updatedAt: now }).where(eq(recurringSeries.id, series.id));
    return Response.json({ ok: true, message: "Recurring series resumed" });
  }
  if (input.action === "delete") {
    await removePristineFutureOccurrences(series.id);
    await db.update(recurringSeries).set({ deletedAt: new Date(), pausedAt: null, updatedAt: new Date() }).where(eq(recurringSeries.id, series.id));
    return Response.json({ ok: true, message: "Recurring series deleted. Existing occurrences were preserved." });
  }

  const previous = await previousOccurrence(task);
  if (!previous) return Response.json({ error: "No previous occurrence exists" }, { status: 404 });
  const now = new Date();
  let addedFiles = await copyTaskAttachments(previous.id, task.id, task.userId);
  let description = task.description;
  if (previous.description?.trim()) {
    const carried = `<strong>Carried forward from previous occurrence</strong><br>${previous.description}`;
    description = description?.trim() ? `${description}<br><br>${carried}` : carried;
    await db.update(tasks).set({ description, updatedAt: now }).where(eq(tasks.id, task.id));
  }
  const previousChildren = await db.select().from(tasks).where(and(eq(tasks.parentId, previous.id), ne(tasks.status, "DONE")));
  const currentChildren = await db.select({ id: tasks.id, title: tasks.title }).from(tasks).where(eq(tasks.parentId, task.id));
  const existingByTitle = new Map(currentChildren.map(child => [child.title.trim().toLowerCase(), child.id]));
  let addedChildren = 0;
  for (const child of previousChildren) {
    const titleKey = child.title.trim().toLowerCase();
    let targetChildId = existingByTitle.get(titleKey);
    if (!targetChildId) {
      targetChildId = crypto.randomUUID();
      await db.insert(tasks).values({
        id: targetChildId, title: child.title, description: child.description, priority: child.priority, status: "TODO",
        startDate: now, dueDate: task.dueDate, plannedDate: task.plannedDate, reminderAt: null, recurrence: "NONE", recurrenceGeneratedAt: null,
        seriesId: null, previousOccurrenceId: child.id, occurrenceDate: null, isArchived: false, userId: task.userId,
        categoryId: task.categoryId, parentId: task.id, createdAt: now, updatedAt: now,
      });
      existingByTitle.set(titleKey, targetChildId);
      addedChildren += 1;
    }
    addedFiles += await copyTaskAttachments(child.id, targetChildId, task.userId);
  }
  return Response.json({ ok: true, task: { ...task, description }, addedChildren, addedFiles, message: "Previous notes, files and unfinished child tasks carried forward" });
}
