CREATE TABLE `google_calendars` (
	`id` text PRIMARY KEY NOT NULL,
	`calendar_id` text NOT NULL,
	`summary` text NOT NULL,
	`color` text,
	`enabled` integer DEFAULT false NOT NULL,
	`user_id` text NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE UNIQUE INDEX `google_calendars_user_calendar_unique` ON `google_calendars` (`user_id`,`calendar_id`);--> statement-breakpoint
CREATE INDEX `google_calendars_user_idx` ON `google_calendars` (`user_id`);--> statement-breakpoint
CREATE TABLE `saved_filters` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`user_id` text NOT NULL,
	`status` text,
	`priority` text,
	`category_id` text,
	`due_window` text DEFAULT 'all' NOT NULL,
	`created_at` integer NOT NULL,
	FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`category_id`) REFERENCES `categories`(`id`) ON UPDATE no action ON DELETE set null
);
--> statement-breakpoint
CREATE INDEX `saved_filters_user_idx` ON `saved_filters` (`user_id`);--> statement-breakpoint
CREATE TABLE `task_templates` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`title` text NOT NULL,
	`description` text,
	`priority` text DEFAULT 'MEDIUM' NOT NULL,
	`status` text DEFAULT 'TODO' NOT NULL,
	`category_id` text,
	`recurrence` text DEFAULT 'NONE' NOT NULL,
	`child_titles` text DEFAULT '[]' NOT NULL,
	`user_id` text NOT NULL,
	`created_at` integer NOT NULL,
	FOREIGN KEY (`category_id`) REFERENCES `categories`(`id`) ON UPDATE no action ON DELETE set null,
	FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `task_templates_user_idx` ON `task_templates` (`user_id`);--> statement-breakpoint
ALTER TABLE `tasks` ADD `planned_date` integer;--> statement-breakpoint
ALTER TABLE `tasks` ADD `reminder_at` integer;--> statement-breakpoint
ALTER TABLE `tasks` ADD `recurrence` text DEFAULT 'NONE' NOT NULL;--> statement-breakpoint
ALTER TABLE `tasks` ADD `recurrence_generated_at` integer;--> statement-breakpoint
ALTER TABLE `users` ADD `google_token_expires_at` integer;--> statement-breakpoint
ALTER TABLE `users` ADD `google_scopes` text;