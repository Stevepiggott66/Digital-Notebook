import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  experimental: {
    serverActions: {
      // Multipart requests are inspected before App Router route handlers run.
      // Keep this slightly above the attachment route's 20 MB file limit so
      // normal form-data overhead does not reject an otherwise valid upload.
      bodySizeLimit: "21mb",
    },
  },
};

export default nextConfig;
