import { inArray } from "drizzle-orm";
import { requireAccess } from "../../access";
import { categoryAccessMap } from "../../category-access";
import { getDb } from "../../../db";
import { categories, gmailThreads, taskAttachments, tasks } from "../../../db/schema";

function csv(value: unknown) { return `"${String(value ?? "").replace(/"/g, '""')}"`; }

export async function GET(request: Request) {
  const access = await requireAccess(); if (access.error || !access.user) return access.error;
  const db = getDb();
  const permissions = await categoryAccessMap(access.user);
  const categoryIds = [...permissions.keys()];
  const [taskRows, categoryRows] = categoryIds.length ? await Promise.all([
    access.user.role === "ADMIN" ? db.select().from(tasks) : db.select().from(tasks).where(inArray(tasks.categoryId, categoryIds)),
    db.select().from(categories).where(inArray(categories.id, categoryIds)),
  ]) : [[], []];
  const ids = taskRows.map(task => task.id);
  const [mail, attachments] = ids.length ? await Promise.all([
    db.select().from(gmailThreads).where(inArray(gmailThreads.taskId, ids)),
    db.select().from(taskAttachments).where(inArray(taskAttachments.taskId, ids)),
  ]) : [[], []];
  if (new URL(request.url).searchParams.get("format") === "csv") {
    const categoryMap = new Map(categoryRows.map(item => [item.id, item.name]));
    const header = ["Title", "Status", "Priority", "Due", "Planned", "Reminder", "Recurrence", "Category", "Archived", "Parent ID", "Notes"].map(csv).join(",");
    const rows = taskRows.map(task => [task.title, task.status, task.priority, task.dueDate?.toISOString() ?? "", task.plannedDate?.toISOString() ?? "", task.reminderAt?.toISOString() ?? "", task.recurrence, categoryMap.get(task.categoryId ?? "") ?? "", task.isArchived, task.parentId ?? "", task.description ?? ""].map(csv).join(","));
    return new Response([header, ...rows].join("\n"), { headers: { "Content-Type": "text/csv; charset=utf-8", "Content-Disposition": `attachment; filename="digital-notebook-${new Date().toISOString().slice(0,10)}.csv"` } });
  }
  const body = JSON.stringify({ exportedAt: new Date().toISOString(), tasks: taskRows, categories: categoryRows, linkedGmail: mail, attachments: attachments.map(item => ({ id: item.id, taskId: item.taskId, fileName: item.fileName, contentType: item.contentType, size: item.size, createdAt: item.createdAt })) }, null, 2);
  return new Response(body, { headers: { "Content-Type": "application/json; charset=utf-8", "Content-Disposition": `attachment; filename="digital-notebook-backup-${new Date().toISOString().slice(0,10)}.json"` } });
}
