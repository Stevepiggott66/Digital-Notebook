import { eq } from "drizzle-orm";
import { requireAccess } from "../../../access";
import { googleConfig } from "../../../google";
import { getDb } from "../../../../db";
import { users } from "../../../../db/schema";

export async function GET(request: Request) {
  const access = await requireAccess(); if (access.error || !access.user) return access.error;
  const account = (await getDb().select({ accessToken: users.googleAccessToken, scopes: users.googleScopes }).from(users).where(eq(users.id, access.user.id)).limit(1))[0];
  return Response.json({ configured: googleConfig(request).configured, connected: Boolean(account?.accessToken), scopes: account?.scopes ?? "" });
}

export async function DELETE() {
  const access = await requireAccess(); if (access.error || !access.user) return access.error;
  await getDb().update(users).set({ googleAccessToken: null, googleRefreshToken: null, googleTokenExpiresAt: null, googleScopes: null, updatedAt: new Date() }).where(eq(users.id, access.user.id));
  return Response.json({ ok: true });
}
