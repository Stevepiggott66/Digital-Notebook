import { requireAccess } from "../../../access";
import { googleFetch } from "../../../google";

type MessageList = { messages?: { id: string }[]; error?: { message?: string } };
type Message = { id: string; snippet?: string; internalDate?: string; payload?: { headers?: { name: string; value: string }[] } };

export async function GET(request: Request) {
  const access = await requireAccess(); if (access.error || !access.user) return access.error;
  const query = new URL(request.url).searchParams.get("q")?.trim(); if (!query) return Response.json({ messages: [] });
  try {
    const listUrl = new URL("https://gmail.googleapis.com/gmail/v1/users/me/messages"); listUrl.search = new URLSearchParams({ q: query, maxResults: "8" }).toString();
    const response = await googleFetch(access.user.id, request, listUrl.toString()); const list = await response.json() as MessageList;
    if (!response.ok) throw new Error(list.error?.message || "Unable to search Gmail");
    const messages = await Promise.all((list.messages ?? []).map(async item => {
      const detailResponse = await googleFetch(access.user!.id, request, `https://gmail.googleapis.com/gmail/v1/users/me/messages/${encodeURIComponent(item.id)}?format=metadata&metadataHeaders=Subject&metadataHeaders=From&metadataHeaders=Date`);
      const message = await detailResponse.json() as Message; const headers = new Map(message.payload?.headers?.map(header => [header.name.toLowerCase(), header.value]));
      return { id: message.id, subject: headers.get("subject") ?? "(No subject)", sender: headers.get("from") ?? "Unknown sender", snippet: message.snippet ?? "", receivedAt: message.internalDate ? new Date(Number(message.internalDate)).toISOString() : headers.get("date") ?? new Date().toISOString(), gmailUrl: `https://mail.google.com/mail/u/0/#inbox/${message.id}` };
    }));
    return Response.json({ messages });
  } catch (error) { return Response.json({ error: error instanceof Error ? error.message : "Unable to search Gmail" }, { status: 409 }); }
}
