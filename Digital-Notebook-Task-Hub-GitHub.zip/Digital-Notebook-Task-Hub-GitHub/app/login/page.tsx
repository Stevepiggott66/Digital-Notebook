import type { Metadata } from "next";
import Link from "next/link";
import { chatGPTSignInPath } from "../chatgpt-auth";

export const metadata: Metadata = {
  title: "Sign in · Digital Notebook",
  description: "Your calm, private place for tasks, notes, and email context.",
};

export default function LoginPage() {
  return (
    <main className="login-shell">
      <section className="login-story" aria-label="Product introduction">
        <Link href="/login" className="login-brand">
          <span className="brand-mark">d</span>
          <span>Digital Notebook</span>
        </Link>
        <div className="story-copy">
          <span className="eyebrow">Your day, gathered thoughtfully</span>
          <h1>Make space for what matters.</h1>
          <p>
            Tasks, notes, calendar plans and important email context—together
            in one quiet, focused workspace.
          </p>
        </div>
        <p className="login-quote">“A clear day begins with a clear page.”</p>
      </section>

      <section className="login-panel">
        <div className="login-card">
          <div className="mobile-login-brand">
            <span className="brand-mark">d</span>
            <span>Digital Notebook</span>
          </div>
          <span className="eyebrow">Welcome back</span>
          <h2>Sign in to your notebook</h2>
          <p className="muted">Pick up exactly where you left off.</p>
          <div className="access-login-note">Only approved email addresses can access this workspace.</div>

          <p className="secure-login-explainer">
            Continue to OpenAI’s secure sign-in and use Google, Microsoft,
            Apple, or an existing OpenAI account associated with your approved
            email address.
          </p>

          <Link className="secure-signin-button" href={chatGPTSignInPath("/")}>
            <span aria-hidden="true">◇</span>
            Continue to secure sign-in
          </Link>

          <p className="login-footnote">
            Digital Notebook never sees or stores your password.
          </p>
        </div>
      </section>
    </main>
  );
}
