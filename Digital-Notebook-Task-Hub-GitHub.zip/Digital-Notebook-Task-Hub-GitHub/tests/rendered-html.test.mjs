import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

const root = new URL("../", import.meta.url);

test("ships the complete planning workspace", async () => {
  const [workspace, schema, hosting] = await Promise.all([
    readFile(new URL("app/workspace.tsx", root), "utf8"),
    readFile(new URL("db/schema.ts", root), "utf8"),
    readFile(new URL(".openai/hosting.json", root), "utf8"),
  ]);

  assert.match(workspace, />Today</);
  assert.match(workspace, />This week</);
  assert.match(workspace, /Task templates/);
  assert.match(workspace, /Google & reminders/);
  assert.match(workspace, /Backup everything/);
  assert.match(workspace, /value="WAITING"/);
  assert.match(schema, /saved_filters/);
  assert.match(schema, /task_templates/);
  assert.match(schema, /google_calendars/);
  assert.deepEqual(JSON.parse(hosting), {
    project_id: "appgprj_6a7fccd5091881918856b52cc65d1365",
    d1: "DB",
    r2: "FILES",
  });
});

test("keeps every new data route behind access control", async () => {
  const routes = [
    "app/api/export/route.ts",
    "app/api/filters/route.ts",
    "app/api/templates/route.ts",
    "app/api/tasks/bulk/route.ts",
    "app/api/google/calendars/route.ts",
    "app/api/google/events/route.ts",
    "app/api/gmail/search/route.ts",
  ];
  for (const route of routes) {
    const source = await readFile(new URL(route, root), "utf8");
    assert.match(source, /requireAccess\(\)/, `${route} must require the current approved user`);
  }
});
