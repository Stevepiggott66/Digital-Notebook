import { index, integer, primaryKey, sqliteTable, text, uniqueIndex, type AnySQLiteColumn } from "drizzle-orm/sqlite-core";

export const users = sqliteTable("users", {
  id: text("id").primaryKey(),
  email: text("email").notNull(),
  name: text("name"),
  image: text("image"),
  googleAccessToken: text("google_access_token"),
  googleRefreshToken: text("google_refresh_token"),
  googleTokenExpiresAt: integer("google_token_expires_at", { mode: "timestamp" }),
  googleScopes: text("google_scopes"),
  createdAt: integer("created_at", { mode: "timestamp" }).notNull(),
  updatedAt: integer("updated_at", { mode: "timestamp" }).notNull(),
}, (table) => [uniqueIndex("users_email_unique").on(table.email)]);

export const allowedUsers = sqliteTable("allowed_users", {
  id: text("id").primaryKey(),
  email: text("email").notNull(),
  role: text("role", { enum: ["ADMIN", "MEMBER"] }).notNull().default("MEMBER"),
  isActive: integer("is_active", { mode: "boolean" }).notNull().default(true),
  createdBy: text("created_by").notNull(),
  createdAt: integer("created_at", { mode: "timestamp" }).notNull(),
}, (table) => [uniqueIndex("allowed_users_email_unique").on(table.email), index("allowed_users_active_idx").on(table.isActive)]);

export const categories = sqliteTable("categories", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  color: text("color"),
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  createdAt: integer("created_at", { mode: "timestamp" }).notNull(),
}, (table) => [index("categories_user_idx").on(table.userId)]);

export const categoryPermissions = sqliteTable("category_permissions", {
  categoryId: text("category_id").notNull().references(() => categories.id, { onDelete: "cascade" }),
  allowedUserId: text("allowed_user_id").notNull().references(() => allowedUsers.id, { onDelete: "cascade" }),
  permission: text("permission", { enum: ["VIEWER", "CONTRIBUTOR", "MANAGER"] }).notNull().default("VIEWER"),
  createdAt: integer("created_at", { mode: "timestamp" }).notNull(),
  updatedAt: integer("updated_at", { mode: "timestamp" }).notNull(),
}, (table) => [primaryKey({ columns: [table.categoryId, table.allowedUserId] }), index("category_permissions_user_idx").on(table.allowedUserId)]);

export const tags = sqliteTable("tags", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
}, (table) => [uniqueIndex("tags_user_name_unique").on(table.userId, table.name)]);

export const recurringSeries = sqliteTable("recurring_series", {
  id: text("id").primaryKey(),
  title: text("title").notNull(),
  priority: text("priority", { enum: ["LOW", "MEDIUM", "HIGH"] }).notNull().default("MEDIUM"),
  recurrence: text("recurrence", { enum: ["DAILY", "WEEKLY", "MONTHLY"] }).notNull(),
  nextOccurrenceAt: integer("next_occurrence_at", { mode: "timestamp" }).notNull(),
  plannedOffsetMinutes: integer("planned_offset_minutes"),
  reminderOffsetMinutes: integer("reminder_offset_minutes"),
  categoryId: text("category_id").references(() => categories.id, { onDelete: "set null" }),
  parentId: text("parent_id"),
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  pausedAt: integer("paused_at", { mode: "timestamp" }),
  deletedAt: integer("deleted_at", { mode: "timestamp" }),
  createdAt: integer("created_at", { mode: "timestamp" }).notNull(),
  updatedAt: integer("updated_at", { mode: "timestamp" }).notNull(),
}, (table) => [index("recurring_series_user_idx").on(table.userId), index("recurring_series_next_idx").on(table.nextOccurrenceAt)]);

export const tasks = sqliteTable("tasks", {
  id: text("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  priority: text("priority", { enum: ["LOW", "MEDIUM", "HIGH"] }).notNull().default("MEDIUM"),
  status: text("status", { enum: ["TODO", "IN_PROGRESS", "WAITING", "DONE"] }).notNull().default("TODO"),
  startDate: integer("start_date", { mode: "timestamp" }).notNull(),
  dueDate: integer("due_date", { mode: "timestamp" }),
  isArchived: integer("is_archived", { mode: "boolean" }).notNull().default(false),
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  categoryId: text("category_id").references(() => categories.id, { onDelete: "set null" }),
  parentId: text("parent_id").references((): AnySQLiteColumn => tasks.id, { onDelete: "cascade" }),
  plannedDate: integer("planned_date", { mode: "timestamp" }),
  reminderAt: integer("reminder_at", { mode: "timestamp" }),
  recurrence: text("recurrence", { enum: ["NONE", "DAILY", "WEEKLY", "MONTHLY"] }).notNull().default("NONE"),
  recurrenceGeneratedAt: integer("recurrence_generated_at", { mode: "timestamp" }),
  seriesId: text("series_id").references(() => recurringSeries.id, { onDelete: "set null" }),
  previousOccurrenceId: text("previous_occurrence_id").references((): AnySQLiteColumn => tasks.id, { onDelete: "set null" }),
  occurrenceDate: integer("occurrence_date", { mode: "timestamp" }),
  createdAt: integer("created_at", { mode: "timestamp" }).notNull(),
  updatedAt: integer("updated_at", { mode: "timestamp" }).notNull(),
}, (table) => [index("tasks_user_archive_idx").on(table.userId, table.isArchived), index("tasks_dates_idx").on(table.startDate, table.dueDate), index("tasks_parent_idx").on(table.parentId), uniqueIndex("tasks_series_occurrence_unique").on(table.seriesId, table.occurrenceDate)]);

export const savedFilters = sqliteTable("saved_filters", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  status: text("status"),
  priority: text("priority"),
  categoryId: text("category_id").references(() => categories.id, { onDelete: "set null" }),
  dueWindow: text("due_window").notNull().default("all"),
  createdAt: integer("created_at", { mode: "timestamp" }).notNull(),
}, (table) => [index("saved_filters_user_idx").on(table.userId)]);

export const taskTemplates = sqliteTable("task_templates", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  title: text("title").notNull(),
  description: text("description"),
  priority: text("priority", { enum: ["LOW", "MEDIUM", "HIGH"] }).notNull().default("MEDIUM"),
  status: text("status", { enum: ["TODO", "IN_PROGRESS", "WAITING", "DONE"] }).notNull().default("TODO"),
  categoryId: text("category_id").references(() => categories.id, { onDelete: "set null" }),
  recurrence: text("recurrence", { enum: ["NONE", "DAILY", "WEEKLY", "MONTHLY"] }).notNull().default("NONE"),
  childTitles: text("child_titles").notNull().default("[]"),
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  createdAt: integer("created_at", { mode: "timestamp" }).notNull(),
}, (table) => [index("task_templates_user_idx").on(table.userId)]);

export const googleCalendars = sqliteTable("google_calendars", {
  id: text("id").primaryKey(),
  calendarId: text("calendar_id").notNull(),
  summary: text("summary").notNull(),
  color: text("color"),
  enabled: integer("enabled", { mode: "boolean" }).notNull().default(false),
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  updatedAt: integer("updated_at", { mode: "timestamp" }).notNull(),
}, (table) => [uniqueIndex("google_calendars_user_calendar_unique").on(table.userId, table.calendarId), index("google_calendars_user_idx").on(table.userId)]);

export const subTasks = sqliteTable("sub_tasks", {
  id: text("id").primaryKey(),
  title: text("title").notNull(),
  isCompleted: integer("is_completed", { mode: "boolean" }).notNull().default(false),
  taskId: text("task_id").notNull().references(() => tasks.id, { onDelete: "cascade" }),
}, (table) => [index("sub_tasks_task_idx").on(table.taskId)]);

export const taskLinks = sqliteTable("task_links", {
  id: text("id").primaryKey(),
  url: text("url").notNull(),
  title: text("title"),
  taskId: text("task_id").notNull().references(() => tasks.id, { onDelete: "cascade" }),
});

export const taskAttachments = sqliteTable("task_attachments", {
  id: text("id").primaryKey(),
  taskId: text("task_id").notNull().references(() => tasks.id, { onDelete: "cascade" }),
  storageKey: text("storage_key").notNull(),
  fileName: text("file_name").notNull(),
  contentType: text("content_type").notNull(),
  size: integer("size").notNull(),
  createdAt: integer("created_at", { mode: "timestamp" }).notNull(),
}, (table) => [uniqueIndex("task_attachments_storage_key_unique").on(table.storageKey), index("task_attachments_task_idx").on(table.taskId)]);

export const gmailThreads = sqliteTable("gmail_threads", {
  id: text("id").primaryKey(),
  messageId: text("message_id").notNull(),
  subject: text("subject").notNull(),
  sender: text("sender").notNull(),
  snippet: text("snippet").notNull(),
  bodyHtml: text("body_html"),
  gmailUrl: text("gmail_url"),
  receivedAt: integer("received_at", { mode: "timestamp" }).notNull(),
  taskId: text("task_id").notNull().references(() => tasks.id, { onDelete: "cascade" }),
}, (table) => [index("gmail_threads_task_idx").on(table.taskId)]);

export const taskTags = sqliteTable("task_tags", {
  taskId: text("task_id").notNull().references(() => tasks.id, { onDelete: "cascade" }),
  tagId: text("tag_id").notNull().references(() => tags.id, { onDelete: "cascade" }),
}, (table) => [primaryKey({ columns: [table.taskId, table.tagId] })]);
