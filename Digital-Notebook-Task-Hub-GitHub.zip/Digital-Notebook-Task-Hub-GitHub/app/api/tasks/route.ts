import { and, asc, eq, gt, inArray, isNotNull } from "drizzle-orm";
import { requireAccess } from "../../access";
import { canUseCategory, canUseTask, categoryAccessMap } from "../../category-access";
import { getFileBucket } from "../../file-storage";
import { dateWithOffset, ensureRecurringTasks, minutesBetween, nextMoment, type Recurrence, type SeriesRecurrence } from "../../recurrence";
import { getDb } from "../../../db";
import { recurringSeries, taskAttachments, tasks } from "../../../db/schema";

type Status = "TODO" | "IN_PROGRESS" | "WAITING" | "DONE";
type Priority = "LOW" | "MEDIUM" | "HIGH";
type TaskInput = { id?: string; title?: string; description?: string | null; priority?: Priority; status?: Status; dueDate?: string | null; plannedDate?: string | null; reminderAt?: string | null; recurrence?: Recurrence; categoryId?: string | null; parentId?: string | null; isArchived?: boolean; editScope?: "occurrence" | "series" };

function dueMoment(value?: string | null) {
  if (!value) return null;
  const parsed = new Date(value);
  return Number.isNaN(parsed.getTime()) ? null : parsed;
}

function sanitizeNotes(value?: string | null) {
  if (!value) return null;
  const allowed = new Set(["b", "strong", "ul", "ol", "li", "br", "p", "div", "blockquote"]);
  return value
    .replace(/<(script|style|iframe|object|embed)[^>]*>[\s\S]*?<\/\1>/gi, "")
    .replace(/<([a-z0-9]+)(?:\s[^>]*)?>/gi, (_, tag: string) => allowed.has(tag.toLowerCase()) ? `<${tag.toLowerCase()}>` : "")
    .replace(/<\/([a-z0-9]+)>/gi, (_, tag: string) => allowed.has(tag.toLowerCase()) ? `</${tag.toLowerCase()}>` : "");
}

export async function GET(request: Request) {
  const access = await requireAccess();
  if (access.error || !access.user) return access.error;
  await ensureRecurringTasks();
  const db = getDb();
  const archive = new URL(request.url).searchParams.get("archived") === "true";
  const permissions = await categoryAccessMap(access.user);
  const categoryIds = [...permissions.keys()];
  const rows = access.user.role === "ADMIN"
    ? await db.select().from(tasks).where(eq(tasks.isArchived, archive)).orderBy(asc(tasks.dueDate), asc(tasks.createdAt))
    : categoryIds.length ? await db.select().from(tasks).where(and(eq(tasks.isArchived, archive), inArray(tasks.categoryId, categoryIds))).orderBy(asc(tasks.dueDate), asc(tasks.createdAt)) : [];
  const seriesRows = await db.select({ id: recurringSeries.id, pausedAt: recurringSeries.pausedAt, deletedAt: recurringSeries.deletedAt }).from(recurringSeries);
  const seriesState = new Map(seriesRows.map(series => [series.id, series]));
  const occurrenceRows = await db.select({ id: tasks.id, seriesId: tasks.seriesId, occurrenceDate: tasks.occurrenceDate }).from(tasks).where(isNotNull(tasks.seriesId)).orderBy(asc(tasks.occurrenceDate));
  const previousByTask = new Map<string, string>();
  const latestBySeries = new Map<string, string>();
  for (const occurrence of occurrenceRows) if (occurrence.seriesId) {
    const previous = latestBySeries.get(occurrence.seriesId);
    if (previous) previousByTask.set(occurrence.id, previous);
    latestBySeries.set(occurrence.seriesId, occurrence.id);
  }
  return Response.json({ tasks: rows.map(task => ({
    ...task,
    previousOccurrenceId: task.previousOccurrenceId ?? previousByTask.get(task.id) ?? null,
    hasPreviousOccurrence: previousByTask.has(task.id),
    seriesPaused: task.seriesId ? Boolean(seriesState.get(task.seriesId)?.pausedAt) : false,
    seriesDeleted: task.seriesId ? Boolean(seriesState.get(task.seriesId)?.deletedAt) : false,
  })) });
}

export async function POST(request: Request) {
  const access = await requireAccess();
  if (access.error || !access.user) return access.error;
  const input = await request.json() as TaskInput;
  if (!input.title?.trim()) return Response.json({ error: "Title is required" }, { status: 400 });
  if (input.parentId && !await canUseTask(access.user, input.parentId, "CONTRIBUTOR")) return Response.json({ error: "You cannot add child tasks to this parent" }, { status: 403 });
  if (!await canUseCategory(access.user, input.categoryId || null, "CONTRIBUTOR")) return Response.json({ error: "Choose a category where you have create access" }, { status: 403 });

  const recurrence = input.recurrence ?? "NONE";
  const dueDate = dueMoment(input.dueDate);
  if (recurrence !== "NONE" && !dueDate) return Response.json({ error: "Choose a due date and time for a repeating task" }, { status: 400 });
  const plannedDate = dueMoment(input.plannedDate);
  const reminderAt = dueMoment(input.reminderAt);
  const now = new Date();
  const db = getDb();
  let seriesId: string | null = null;

  if (recurrence !== "NONE" && dueDate) {
    seriesId = crypto.randomUUID();
    await db.insert(recurringSeries).values({
      id: seriesId,
      title: input.title.trim(),
      priority: input.priority ?? "MEDIUM",
      recurrence,
      nextOccurrenceAt: nextMoment(dueDate, recurrence),
      plannedOffsetMinutes: minutesBetween(plannedDate, dueDate),
      reminderOffsetMinutes: minutesBetween(reminderAt, dueDate),
      categoryId: input.categoryId || null,
      parentId: input.parentId || null,
      userId: access.user.id,
      pausedAt: null,
      deletedAt: null,
      createdAt: now,
      updatedAt: now,
    });
  }

  const task = {
    id: crypto.randomUUID(), title: input.title.trim(), description: sanitizeNotes(input.description), priority: input.priority ?? "MEDIUM" as Priority,
    status: input.status ?? "TODO" as Status, startDate: now, dueDate, plannedDate, reminderAt, recurrence, recurrenceGeneratedAt: null,
    seriesId, previousOccurrenceId: null, occurrenceDate: seriesId ? dueDate : null, isArchived: false, userId: access.user.id,
    categoryId: input.categoryId || null, parentId: input.parentId || null, createdAt: now, updatedAt: now,
  };
  try { await db.insert(tasks).values(task); }
  catch (error) { if (seriesId) await db.delete(recurringSeries).where(eq(recurringSeries.id, seriesId)); throw error; }
  return Response.json({ task: { ...task, hasPreviousOccurrence: false, seriesPaused: false, seriesDeleted: false } }, { status: 201 });
}

export async function PATCH(request: Request) {
  const access = await requireAccess();
  if (access.error || !access.user) return access.error;
  const input = await request.json() as TaskInput;
  if (!input.id) return Response.json({ error: "Task id is required" }, { status: 400 });
  const requiredPermission = input.isArchived !== undefined ? "MANAGER" : "CONTRIBUTOR";
  if (!await canUseTask(access.user, input.id, requiredPermission)) return Response.json({ error: `You need ${requiredPermission === "MANAGER" ? "manager" : "edit"} access for this task` }, { status: 403 });
  const db = getDb();
  const source = (await db.select().from(tasks).where(eq(tasks.id, input.id)).limit(1))[0];
  if (!source) return Response.json({ error: "Task not found" }, { status: 404 });
  if (input.categoryId !== undefined && !await canUseCategory(access.user, input.categoryId || null, "CONTRIBUTOR")) return Response.json({ error: "You cannot move this task to that category" }, { status: 403 });
  if (input.parentId && !await canUseTask(access.user, input.parentId, "CONTRIBUTOR")) return Response.json({ error: "You cannot use that parent task" }, { status: 403 });

  let archiveDescendantIds: string[] = [];
  if (input.isArchived !== undefined) {
    const allTasks = await db.select({ id: tasks.id, parentId: tasks.parentId }).from(tasks);
    const branchIds = new Set([input.id]);
    let foundDescendant = true;
    while (foundDescendant) {
      foundDescendant = false;
      for (const task of allTasks) if (task.parentId && branchIds.has(task.parentId) && !branchIds.has(task.id)) { branchIds.add(task.id); foundDescendant = true; }
    }
    archiveDescendantIds = [...branchIds].filter(id => id !== input.id);
    for (const id of archiveDescendantIds) if (!await canUseTask(access.user, id, "MANAGER")) return Response.json({ error: "Manager access is required for every child task in this branch" }, { status: 403 });
  }

  const requestedRecurrence = input.recurrence ?? source.recurrence;
  const requestedDueDate = input.dueDate !== undefined ? dueMoment(input.dueDate) : source.dueDate;
  const editWholeSeries = Boolean(source.seriesId && input.editScope === "series");
  if ((editWholeSeries || (!source.seriesId && requestedRecurrence !== "NONE")) && requestedRecurrence !== "NONE" && !requestedDueDate) return Response.json({ error: "Choose a due date and time for a repeating task" }, { status: 400 });

  let seriesId = source.seriesId;
  let occurrenceDate = source.occurrenceDate;
  let effectiveRecurrence = source.seriesId && !editWholeSeries ? source.recurrence : requestedRecurrence;

  if (!source.seriesId && requestedRecurrence !== "NONE" && requestedDueDate) {
    seriesId = crypto.randomUUID();
    occurrenceDate = requestedDueDate;
    const seriesRecurrence = requestedRecurrence as SeriesRecurrence;
    await db.insert(recurringSeries).values({
      id: seriesId, title: input.title?.trim() || source.title, priority: input.priority ?? source.priority, recurrence: seriesRecurrence,
      nextOccurrenceAt: nextMoment(requestedDueDate, seriesRecurrence),
      plannedOffsetMinutes: minutesBetween(input.plannedDate !== undefined ? dueMoment(input.plannedDate) : source.plannedDate, requestedDueDate),
      reminderOffsetMinutes: minutesBetween(input.reminderAt !== undefined ? dueMoment(input.reminderAt) : source.reminderAt, requestedDueDate),
      categoryId: input.categoryId !== undefined ? input.categoryId || null : source.categoryId,
      parentId: input.parentId !== undefined ? input.parentId || null : source.parentId,
      userId: source.userId, pausedAt: null, deletedAt: null, createdAt: new Date(), updatedAt: new Date(),
    });
  }

  if (source.seriesId && editWholeSeries) {
    const series = (await db.select().from(recurringSeries).where(eq(recurringSeries.id, source.seriesId)).limit(1))[0];
    if (series) {
      if (requestedRecurrence === "NONE") {
        await db.update(recurringSeries).set({ deletedAt: new Date(), updatedAt: new Date() }).where(eq(recurringSeries.id, series.id));
        effectiveRecurrence = "NONE";
      } else if (requestedDueDate) {
        const recurrence = requestedRecurrence as SeriesRecurrence;
        const baseOccurrence = source.occurrenceDate ?? source.dueDate ?? requestedDueDate;
        const future = await db.select().from(tasks).where(and(eq(tasks.seriesId, series.id), gt(tasks.occurrenceDate, baseOccurrence))).orderBy(asc(tasks.occurrenceDate));
        if (future.length) await db.update(tasks).set({ seriesId: null }).where(inArray(tasks.id, future.map(task => task.id)));
        occurrenceDate = requestedDueDate;
        let cursor = requestedDueDate;
        let previousId = source.id;
        const plannedOffset = minutesBetween(input.plannedDate !== undefined ? dueMoment(input.plannedDate) : source.plannedDate, requestedDueDate);
        const reminderOffset = minutesBetween(input.reminderAt !== undefined ? dueMoment(input.reminderAt) : source.reminderAt, requestedDueDate);
        const seriesTitle = input.title?.trim() || source.title;
        const seriesPriority = input.priority ?? source.priority;
        const seriesCategory = input.categoryId !== undefined ? input.categoryId || null : source.categoryId;
        const seriesParent = input.parentId !== undefined ? input.parentId || null : source.parentId;
        for (const futureTask of future) {
          cursor = nextMoment(cursor, recurrence);
          await db.update(tasks).set({
            seriesId: series.id, previousOccurrenceId: previousId, occurrenceDate: cursor, dueDate: cursor,
            plannedDate: dateWithOffset(cursor, plannedOffset), reminderAt: dateWithOffset(cursor, reminderOffset), recurrence,
            title: seriesTitle, priority: seriesPriority, categoryId: seriesCategory, parentId: seriesParent, updatedAt: new Date(),
          }).where(eq(tasks.id, futureTask.id));
          previousId = futureTask.id;
        }
        const nextOccurrenceAt = nextMoment(cursor, recurrence);
        await db.update(recurringSeries).set({
          title: seriesTitle, priority: seriesPriority, recurrence, nextOccurrenceAt, plannedOffsetMinutes: plannedOffset,
          reminderOffsetMinutes: reminderOffset, categoryId: seriesCategory, parentId: seriesParent, deletedAt: null, updatedAt: new Date(),
        }).where(eq(recurringSeries.id, series.id));
        effectiveRecurrence = recurrence;
      }
    }
  }

  const patch = {
    ...(input.title !== undefined && { title: input.title.trim() }),
    ...(input.description !== undefined && { description: sanitizeNotes(input.description) }),
    ...(input.status !== undefined && { status: input.status }),
    ...(input.priority !== undefined && { priority: input.priority }),
    ...(input.dueDate !== undefined && { dueDate: dueMoment(input.dueDate) }),
    ...(input.plannedDate !== undefined && { plannedDate: dueMoment(input.plannedDate) }),
    ...(input.reminderAt !== undefined && { reminderAt: dueMoment(input.reminderAt) }),
    ...((!source.seriesId || editWholeSeries) && { recurrence: effectiveRecurrence }),
    ...(input.categoryId !== undefined && { categoryId: input.categoryId || null }),
    ...(input.parentId !== undefined && { parentId: input.parentId || null }),
    ...(input.isArchived !== undefined && { isArchived: input.isArchived }),
    ...(seriesId !== source.seriesId && { seriesId }),
    ...(occurrenceDate !== source.occurrenceDate && { occurrenceDate }),
    updatedAt: new Date(),
  };
  if ("title" in patch && !patch.title) return Response.json({ error: "Title is required" }, { status: 400 });
  const updated = await db.update(tasks).set(patch).where(eq(tasks.id, input.id)).returning();
  if (!updated[0]) return Response.json({ error: "Task not found" }, { status: 404 });
  if (input.isArchived !== undefined && archiveDescendantIds.length) await db.update(tasks).set({ isArchived: input.isArchived, updatedAt: new Date() }).where(inArray(tasks.id, archiveDescendantIds));
  return Response.json({ task: updated[0] });
}

export async function DELETE(request: Request) {
  const access = await requireAccess();
  if (access.error || !access.user) return access.error;
  const id = new URL(request.url).searchParams.get("id");
  if (!id) return Response.json({ error: "Task id is required" }, { status: 400 });
  if (!await canUseTask(access.user, id, "MANAGER")) return Response.json({ error: "Manager access is required to delete this task" }, { status: 403 });
  const db = getDb();
  const ownedTasks = await db.select({ id: tasks.id, parentId: tasks.parentId }).from(tasks);
  if (!ownedTasks.some(task => task.id === id)) return Response.json({ error: "Task not found" }, { status: 404 });
  const removedTaskIds = new Set([id]);
  let foundDescendant = true;
  while (foundDescendant) {
    foundDescendant = false;
    for (const task of ownedTasks) if (task.parentId && removedTaskIds.has(task.parentId) && !removedTaskIds.has(task.id)) { removedTaskIds.add(task.id); foundDescendant = true; }
  }
  for (const taskId of removedTaskIds) if (!await canUseTask(access.user, taskId, "MANAGER")) return Response.json({ error: "Manager access is required for every child task in this branch" }, { status: 403 });
  const storedFiles = await db.select({ storageKey: taskAttachments.storageKey }).from(taskAttachments).where(inArray(taskAttachments.taskId, [...removedTaskIds]));
  if (storedFiles.length) {
    const bucket = getFileBucket();
    for (let index = 0; index < storedFiles.length; index += 1000) await bucket.delete(storedFiles.slice(index, index + 1000).map(file => file.storageKey));
  }
  const removed = await db.delete(tasks).where(eq(tasks.id, id)).returning({ id: tasks.id });
  if (!removed[0]) return Response.json({ error: "Task not found" }, { status: 404 });
  return Response.json({ ok: true });
}
