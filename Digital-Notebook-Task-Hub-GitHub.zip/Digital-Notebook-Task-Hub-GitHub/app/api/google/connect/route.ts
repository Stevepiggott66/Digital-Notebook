import { requireAccess } from "../../../access";
import { googleConfig } from "../../../google";

export async function GET(request: Request) {
  const access = await requireAccess(); if (access.error || !access.user) return access.error;
  const config = googleConfig(request);
  if (!config.configured) return Response.json({ error: "Google integration needs its client credentials configured by the site administrator" }, { status: 503 });
  const state = crypto.randomUUID();
  const url = new URL("https://accounts.google.com/o/oauth2/v2/auth");
  url.search = new URLSearchParams({ client_id: config.clientId, redirect_uri: config.redirectUri, response_type: "code", access_type: "offline", prompt: "consent", include_granted_scopes: "true", login_hint: access.user.email, state, scope: "openid email https://www.googleapis.com/auth/gmail.readonly https://www.googleapis.com/auth/calendar.readonly" }).toString();
  return new Response(null, { status: 302, headers: { Location: url.toString(), "Set-Cookie": `google_oauth_state=${state}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=600` } });
}
