import { env } from "cloudflare:workers";
import { eq } from "drizzle-orm";
import { getDb } from "../db";
import { users } from "../db/schema";

type GoogleTokenResponse = { access_token?: string; refresh_token?: string; expires_in?: number; scope?: string; error?: string; error_description?: string };

export function googleConfig(request: Request) {
  const runtime = env as unknown as Record<string, unknown>;
  const clientId = String(runtime.GOOGLE_CLIENT_ID ?? "");
  const clientSecret = String(runtime.GOOGLE_CLIENT_SECRET ?? "");
  return { clientId, clientSecret, redirectUri: `${new URL(request.url).origin}/api/google/callback`, configured: Boolean(clientId && clientSecret) };
}

export async function googleAccessToken(userId: string, request: Request) {
  const account = (await getDb().select().from(users).where(eq(users.id, userId)).limit(1))[0];
  if (!account?.googleAccessToken) throw new Error("Connect Google to use Calendar and Gmail search");
  const expiresSoon = account.googleTokenExpiresAt && account.googleTokenExpiresAt.getTime() <= Date.now() + 60_000;
  if (!expiresSoon) return account.googleAccessToken;
  if (!account.googleRefreshToken) throw new Error("Your Google connection has expired. Please reconnect.");
  const config = googleConfig(request); if (!config.configured) throw new Error("Google integration is not configured");
  const response = await fetch("https://oauth2.googleapis.com/token", { method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body: new URLSearchParams({ client_id: config.clientId, client_secret: config.clientSecret, refresh_token: account.googleRefreshToken, grant_type: "refresh_token" }) });
  const token = await response.json() as GoogleTokenResponse;
  if (!response.ok || !token.access_token) throw new Error(token.error_description || "Google connection could not be refreshed");
  const expiresAt = new Date(Date.now() + (token.expires_in ?? 3600) * 1000);
  await getDb().update(users).set({ googleAccessToken: token.access_token, googleTokenExpiresAt: expiresAt, updatedAt: new Date() }).where(eq(users.id, userId));
  return token.access_token;
}

export async function googleFetch(userId: string, request: Request, url: string) {
  const token = await googleAccessToken(userId, request);
  return fetch(url, { headers: { Authorization: `Bearer ${token}` } });
}
