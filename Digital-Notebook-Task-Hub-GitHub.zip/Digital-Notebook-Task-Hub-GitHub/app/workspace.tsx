"use client";

import { FormEvent, useCallback, useEffect, useMemo, useRef, useState } from "react";

type Status = "TODO" | "IN_PROGRESS" | "WAITING" | "DONE";
type Priority = "LOW" | "MEDIUM" | "HIGH";
type Recurrence = "NONE" | "DAILY" | "WEEKLY" | "MONTHLY";
type CategoryPermission = "VIEWER" | "CONTRIBUTOR" | "MANAGER";
type View = "dashboard" | "today" | "week" | "all" | "calendar" | "board" | "category_board";
type SummaryFilter = "all" | "TODO" | "IN_PROGRESS" | "OVERDUE";
type DueWindow = "all" | "today" | "week" | "overdue" | "no_date";
type Task = { id: string; title: string; description: string | null; priority: Priority; status: Status; dueDate: string | null; plannedDate: string | null; reminderAt: string | null; recurrence: Recurrence; isArchived: boolean; categoryId: string | null; parentId: string | null; seriesId: string | null; previousOccurrenceId: string | null; occurrenceDate: string | null; hasPreviousOccurrence: boolean; seriesPaused: boolean; seriesDeleted: boolean; createdAt: string };
type Category = { id: string; name: string; color: string | null; taskCount: number; permission: CategoryPermission };
type AllowedUser = { id: string; email: string; role: "ADMIN" | "MEMBER"; isActive: boolean; createdAt: string; categoryPermissions: { categoryId: string; permission: CategoryPermission }[] };
type TaskDraft = { id?: string; title: string; description: string; priority: Priority; status: Status; dueDate: string; plannedDate: string; reminderAt: string; recurrence: Recurrence; categoryId: string; parentId: string };
type GmailLink = { id: string; messageId: string; subject: string; sender: string; snippet: string; gmailUrl: string | null; receivedAt: string };
type Attachment = { id: string; taskId: string; fileName: string; contentType: string; size: number; createdAt: string };
type SavedFilter = { id: string; name: string; status: string | null; priority: string | null; categoryId: string | null; dueWindow: DueWindow };
type TaskTemplate = { id: string; name: string; title: string; description: string | null; priority: Priority; status: Status; categoryId: string | null; recurrence: Recurrence; childTitles: string[] };
type GoogleCalendar = { calendarId: string; summary: string; color: string | null; enabled: boolean };
type GoogleEvent = { id: string; title: string; start: string; end: string; date: string; url: string | null; calendar: string; color: string };
type GoogleStatus = { configured: boolean; connected: boolean; scopes: string };
type TaskWindow = { key: string; draft: TaskDraft; x: number; y: number; z: number; templateChildren: string[] };

const emptyDraft: TaskDraft = { title: "", description: "", priority: "MEDIUM", status: "TODO", dueDate: "", plannedDate: "", reminderAt: "", recurrence: "NONE", categoryId: "", parentId: "" };
const colours = ["#6556a5", "#5f846a", "#b37a3e", "#bd6d63", "#557f95", "#936c86"];

function Icon({ name }: { name: string }) {
  const icons: Record<string, string> = { home: "⌂", calendar: "□", board: "▥", category: "▦", archive: "▣", search: "⌕", plus: "+", close: "×", sun: "☼", check: "✓", edit: "✎", trash: "⌫", chevron: "›", down: "⌄", people: "♙", settings: "⚙", more: "•••", list: "☷", lock: "◇", mail: "✉", attachment: "⌇", file: "▤" };
  return <span className={`icon icon-${name}`} aria-hidden="true">{icons[name] ?? "·"}</span>;
}

function dateTimeValue(value: string | null) { return value ? value.slice(0, 16) : ""; }
function draftFromTask(task: Task): TaskDraft { return { id: task.id, title: task.title, description: task.description ?? "", priority: task.priority, status: task.status, dueDate: dateTimeValue(task.dueDate), plannedDate: dateTimeValue(task.plannedDate), reminderAt: dateTimeValue(task.reminderAt), recurrence: task.recurrence, categoryId: task.categoryId ?? "", parentId: task.parentId ?? "" }; }
function formatDue(value: string | null) {
  if (!value) return "No due date";
  const due = new Date(value); const hasTime = due.getUTCHours() !== 0 || due.getUTCMinutes() !== 0;
  return new Intl.DateTimeFormat("en-AU", { day: "numeric", month: "short", year: "numeric", ...(hasTime ? { hour: "numeric", minute: "2-digit" } : {}), timeZone: "UTC" }).format(due);
}
function plainText(value: string | null) { return (value ?? "").replace(/<[^>]*>/g, " ").replace(/\s+/g, " ").trim(); }
function isOverdue(task: Task) {
  if (!task.dueDate || task.status === "DONE") return false;
  const today = new Date(); today.setHours(0, 0, 0, 0);
  return new Date(task.dueDate) < today;
}
function dateKey(value: string | Date) { return new Date(value).toISOString().slice(0, 10); }
function sydneyDateKey(value: Date) {
  const parts = new Intl.DateTimeFormat("en-AU", { timeZone: "Australia/Sydney", year: "numeric", month: "2-digit", day: "2-digit" }).formatToParts(value);
  const part = (type: Intl.DateTimeFormatPartTypes) => parts.find(item => item.type === type)?.value ?? "";
  return `${part("year")}-${part("month")}-${part("day")}`;
}
function rangeForThisWeek() {
  const now = new Date(); const start = new Date(now); start.setHours(0, 0, 0, 0); start.setDate(start.getDate() - ((start.getDay() + 6) % 7));
  const end = new Date(start); end.setDate(end.getDate() + 7); return { start, end };
}

function occurrenceTime(task: Task) {
  const value = task.occurrenceDate || task.dueDate || task.createdAt;
  const timestamp = new Date(value).getTime();
  return Number.isNaN(timestamp) ? Number.MAX_SAFE_INTEGER : timestamp;
}

function collapseRecurringOccurrences(source: Task[]) {
  const series = new Map<string, Task[]>();
  for (const task of source) if (task.seriesId) series.set(task.seriesId, [...(series.get(task.seriesId) ?? []), task]);
  if (!series.size) return source;

  const today = new Date(); today.setHours(0, 0, 0, 0);
  const hidden = new Set<string>();
  for (const occurrences of series.values()) {
    const ordered = [...occurrences].sort((left, right) => occurrenceTime(left) - occurrenceTime(right));
    const overdue = ordered.filter(task => task.status !== "DONE" && occurrenceTime(task) < today.getTime()).at(-1);
    const upcoming = ordered.find(task => task.status !== "DONE" && occurrenceTime(task) >= today.getTime());
    const nextScheduled = ordered.find(task => occurrenceTime(task) >= today.getTime());
    const shown = overdue ?? upcoming ?? nextScheduled;
    for (const task of ordered) if (task.id !== shown?.id) hidden.add(task.id);
  }

  const byId = new Map(source.map(task => [task.id, task]));
  const belongsToHiddenOccurrence = (task: Task) => {
    let parentId = task.parentId;
    const visited = new Set<string>();
    while (parentId && !visited.has(parentId)) {
      if (hidden.has(parentId)) return true;
      visited.add(parentId);
      parentId = byId.get(parentId)?.parentId ?? null;
    }
    return false;
  };
  return source.filter(task => !hidden.has(task.id) && !belongsToHiddenOccurrence(task));
}

async function api<T>(url: string, options?: RequestInit): Promise<T> {
  const response = await fetch(url, { ...options, headers: { "Content-Type": "application/json", ...(options?.headers ?? {}) } });
  const body = await response.json() as T & { error?: string };
  if (!response.ok) throw new Error(body.error ?? "Something went wrong");
  return body;
}

export function Workspace({ user }: { user: { name: string; email: string; isAdmin: boolean } }) {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [view, setView] = useState<View>("dashboard");
  const [summaryFilter, setSummaryFilter] = useState<SummaryFilter>("all");
  const [archived, setArchived] = useState(false);
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [expanded, setExpanded] = useState<Set<string>>(new Set());
  const [taskWindows, setTaskWindows] = useState<TaskWindow[]>([]);
  const [categoryManager, setCategoryManager] = useState(false);
  const [accessManager, setAccessManager] = useState(false);
  const [templateManager, setTemplateManager] = useState(false);
  const [googleManager, setGoogleManager] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [manageOpen, setManageOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const [mobileNav, setMobileNav] = useState(false);
  const [sidebarHidden, setSidebarHidden] = useState(false);
  const [query, setQuery] = useState("");
  const [loading, setLoading] = useState(true);
  const [notice, setNotice] = useState("");
  const [dark, setDark] = useState(false);
  const [savedFilters, setSavedFilters] = useState<SavedFilter[]>([]);
  const [templates, setTemplates] = useState<TaskTemplate[]>([]);
  const [statusFilter, setStatusFilter] = useState<Status | "all">("all");
  const [priorityFilter, setPriorityFilter] = useState<Priority | "all">("all");
  const [dueWindow, setDueWindow] = useState<DueWindow>("all");
  const [showAllOccurrences, setShowAllOccurrences] = useState(false);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [googleStatus, setGoogleStatus] = useState<GoogleStatus>({ configured: false, connected: false, scopes: "" });
  const [googleEvents, setGoogleEvents] = useState<GoogleEvent[]>([]);
  const reminded = useRef(new Set<string>());
  const taskWindowSequence = useRef(0);
  const taskWindowZ = useRef(70);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [taskData, categoryData] = await Promise.all([
        api<{ tasks: Task[] }>(`/api/tasks?archived=${archived}`),
        api<{ categories: Category[] }>("/api/categories"),
      ]);
      setTasks(taskData.tasks); setCategories(categoryData.categories);
      setExpanded(new Set(taskData.tasks.filter(task => !task.parentId).map(task => task.id)));
    } catch (error) { setNotice(error instanceof Error ? error.message : "Unable to load your notebook"); }
    finally { setLoading(false); }
  }, [archived]);

  const loadPreferences = useCallback(async () => {
    const [filterData, templateData, googleData] = await Promise.all([
      api<{ filters: SavedFilter[] }>("/api/filters"),
      api<{ templates: TaskTemplate[] }>("/api/templates"),
      api<GoogleStatus>("/api/google/status"),
    ]);
    setSavedFilters(filterData.filters); setTemplates(templateData.templates); setGoogleStatus(googleData);
  }, []);

  const openTaskWindow = useCallback((draft: TaskDraft, templateChildren: string[] = []) => {
    setTaskWindows(current => {
      const existing = draft.id ? current.find(item => item.draft.id === draft.id) : undefined;
      const z = ++taskWindowZ.current;
      if (existing) return current.map(item => item.key === existing.key ? { ...item, z } : item);
      const offset = (current.length % 7) * 28;
      const width = Math.min(560, window.innerWidth - 32);
      const x = Math.min(Math.max(16, (window.innerWidth - width) / 2 + offset), Math.max(16, window.innerWidth - width - 16));
      const y = Math.min(72 + offset, Math.max(16, window.innerHeight - 160));
      return [...current, { key: `task-window-${++taskWindowSequence.current}`, draft, x, y, z, templateChildren }];
    });
  }, []);
  const closeTaskWindow = useCallback((key: string) => setTaskWindows(current => current.filter(item => item.key !== key)), []);
  const focusTaskWindow = useCallback((key: string) => { const z = ++taskWindowZ.current; setTaskWindows(current => current.map(item => item.key === key ? { ...item, z } : item)); }, []);
  const moveTaskWindow = useCallback((key: string, x: number, y: number) => setTaskWindows(current => current.map(item => item.key === key ? { ...item, x, y } : item)), []);

  const startTask = useCallback((overrides: Partial<TaskDraft> = {}) => {
    const firstWritable = categories.find(category => category.permission === "CONTRIBUTOR" || category.permission === "MANAGER");
    if (!user.isAdmin && !firstWritable) { setNotice("You need contributor access to a category before creating tasks"); return; }
    openTaskWindow({ ...emptyDraft, categoryId: user.isAdmin ? "" : firstWritable!.id, ...overrides });
  }, [categories, user.isAdmin, openTaskWindow]);

  useEffect(() => { const timer = window.setTimeout(() => void load(), 0); return () => window.clearTimeout(timer); }, [load]);
  useEffect(() => { const timer = window.setTimeout(() => void loadPreferences().catch(() => undefined), 0); return () => window.clearTimeout(timer); }, [loadPreferences]);
  useEffect(() => {
    const timer = window.setTimeout(() => {
      if (!googleStatus.connected) { setGoogleEvents([]); return; }
      const from = new Date(); from.setMonth(from.getMonth() - 2); const to = new Date(); to.setMonth(to.getMonth() + 5);
      void api<{ events: GoogleEvent[] }>(`/api/google/events?from=${encodeURIComponent(from.toISOString())}&to=${encodeURIComponent(to.toISOString())}`).then(data => setGoogleEvents(data.events)).catch(() => setGoogleEvents([]));
    }, 0);
    return () => window.clearTimeout(timer);
  }, [googleStatus.connected, googleManager]);
  useEffect(() => { document.documentElement.dataset.theme = dark ? "dark" : "light"; }, [dark]);
  useEffect(() => {
    const check = () => tasks.filter(task => task.status !== "DONE" && task.reminderAt && new Date(task.reminderAt) <= new Date() && !reminded.current.has(task.id)).forEach(task => {
      reminded.current.add(task.id); setNotice(`Reminder: ${task.title}`);
      if ("Notification" in window && Notification.permission === "granted") new Notification("Digital Notebook reminder", { body: task.title });
    });
    check(); const timer = window.setInterval(check, 60_000); return () => window.clearInterval(timer);
  }, [tasks]);
  useEffect(() => {
    const keyboard = (event: KeyboardEvent) => {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k") { event.preventDefault(); setSearchOpen(true); }
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "n") { event.preventDefault(); startTask(); }
      if (event.key === "Escape") { setSearchOpen(false); setTaskWindows(current => { if (!current.length) return current; const top = current.reduce((highest, item) => item.z > highest.z ? item : highest); return current.filter(item => item.key !== top.key); }); setCategoryManager(false); setAccessManager(false); setTemplateManager(false); setGoogleManager(false); }
    };
    window.addEventListener("keydown", keyboard); return () => window.removeEventListener("keydown", keyboard);
  }, [startTask]);

  const categoryMap = useMemo(() => new Map(categories.map(category => [category.id, category])), [categories]);
  const activeCategoryFilter = categoryFilter === "all" || categories.some(category => category.id === categoryFilter) ? categoryFilter : "all";
  const recurringDisplayTasks = useMemo(() => view === "calendar" || showAllOccurrences ? tasks : collapseRecurringOccurrences(tasks), [tasks, view, showAllOccurrences]);
  const displayCountTasks = useMemo(() => showAllOccurrences ? tasks : collapseRecurringOccurrences(tasks), [tasks, showAllOccurrences]);
  const matchesFilters = useCallback((task: Task, includeView: boolean) => {
    const categoryMatches = activeCategoryFilter === "all" || task.categoryId === activeCategoryFilter;
    const summaryMatches = summaryFilter === "all" || (summaryFilter === "OVERDUE" ? isOverdue(task) : task.status === summaryFilter);
    const statusMatches = statusFilter === "all" || task.status === statusFilter;
    const priorityMatches = priorityFilter === "all" || task.priority === priorityFilter;
    const today = dateKey(new Date()); const week = rangeForThisWeek(); const due = task.dueDate ? new Date(task.dueDate) : null;
    const dueMatches = dueWindow === "all" || (dueWindow === "today" && Boolean(due && dateKey(due) === today)) || (dueWindow === "week" && Boolean(due && due >= week.start && due < week.end)) || (dueWindow === "overdue" && isOverdue(task)) || (dueWindow === "no_date" && !due);
    const plannedOrDue = task.plannedDate || task.dueDate;
    const viewMatches = !includeView ? true : view === "today" ? task.status !== "DONE" && (isOverdue(task) || Boolean(plannedOrDue && dateKey(plannedOrDue) === today)) : view === "week" ? task.status !== "DONE" && Boolean(plannedOrDue && new Date(plannedOrDue) >= week.start && new Date(plannedOrDue) < week.end) : true;
    return categoryMatches && summaryMatches && statusMatches && priorityMatches && dueMatches && viewMatches;
  }, [activeCategoryFilter, summaryFilter, statusFilter, priorityFilter, dueWindow, view]);
  const visibleTasks = useMemo(() => recurringDisplayTasks.filter(task => matchesFilters(task, true)), [recurringDisplayTasks, matchesFilters]);
  const dashboardCalendarTasks = useMemo(() => tasks.filter(task => matchesFilters(task, false)), [tasks, matchesFilters]);
  const topTasks = useMemo(() => visibleTasks.filter(task => !task.parentId || !visibleTasks.some(parent => parent.id === task.parentId)), [visibleTasks]);
  const notStartedCount = displayCountTasks.filter(task => task.status === "TODO").length;
  const startedCount = displayCountTasks.filter(task => task.status === "IN_PROGRESS").length;
  const overdueCount = displayCountTasks.filter(isOverdue).length;

  function openView(nextView: View) { setArchived(false); setSummaryFilter("all"); setSelected(new Set()); setView(nextView); }
  function showSummary(filter: SummaryFilter) { setArchived(false); setSummaryFilter(filter); setView("all"); }

  function editTask(task: Task) {
    openTaskWindow(draftFromTask(task));
  }
  function addChild(parent: Task) {
    setExpanded(current => new Set(current).add(parent.id));
    openTaskWindow({ ...emptyDraft, parentId: parent.id, categoryId: parent.categoryId ?? "", dueDate: dateTimeValue(parent.dueDate), plannedDate: dateTimeValue(parent.plannedDate) });
  }
  async function saveTask(windowKey: string, draft: TaskDraft, templateChildren: string[], editScope: "occurrence" | "series") {
    const payload = { ...draft, editScope, dueDate: draft.dueDate || null, plannedDate: draft.plannedDate || null, reminderAt: draft.reminderAt || null, categoryId: draft.categoryId || null, parentId: draft.parentId || null };
    const data = await api<{ task: Task }>("/api/tasks", { method: draft.id ? "PATCH" : "POST", body: JSON.stringify(payload) });
    if (!draft.id && templateChildren.length) {
      for (const title of templateChildren) await api("/api/tasks", { method: "POST", body: JSON.stringify({ ...emptyDraft, title, parentId: data.task.id, categoryId: draft.categoryId || null, priority: draft.priority }) });
    }
    closeTaskWindow(windowKey); setNotice(draft.id ? "Task updated" : draft.parentId ? "Child task added" : "Task added"); await load();
  }
  async function openPreviousOccurrence(taskId: string) {
    try { const data = await api<{ previous: Task }>(`/api/recurrence?taskId=${encodeURIComponent(taskId)}`); editTask(data.previous); }
    catch (error) { setNotice(error instanceof Error ? error.message : "Unable to open the previous occurrence"); }
  }
  async function updateRecurringSeries(taskId: string, action: "pause" | "resume" | "delete") {
    try { const data = await api<{ message: string }>("/api/recurrence", { method: "POST", body: JSON.stringify({ taskId, action }) }); setNotice(data.message); await load(); }
    catch (error) { setNotice(error instanceof Error ? error.message : "Unable to update the recurring series"); }
  }
  async function deleteTask(windowKey: string, id: string) {
    await api(`/api/tasks?id=${encodeURIComponent(id)}`, { method: "DELETE" }); closeTaskWindow(windowKey); setNotice("Task deleted"); await load();
  }
  async function setTaskArchived(windowKey: string, id: string, isArchived: boolean) {
    await api("/api/tasks", { method: "PATCH", body: JSON.stringify({ id, isArchived }) });
    closeTaskWindow(windowKey); setNotice(isArchived ? "Task moved to Archive" : "Task restored"); await load();
  }
  async function toggleTask(task: Task) {
    const permission = categoryMap.get(task.categoryId ?? "")?.permission;
    if (!user.isAdmin && permission !== "CONTRIBUTOR" && permission !== "MANAGER") { setNotice("This category is view only"); return; }
    const status: Status = task.status === "DONE" ? "TODO" : "DONE";
    setTasks(current => current.map(item => item.id === task.id ? { ...item, status } : item));
    try { await api("/api/tasks", { method: "PATCH", body: JSON.stringify({ id: task.id, status }) }); } catch { await load(); }
  }

  async function quickPatch(id: string, patch: Partial<Pick<Task, "title" | "status" | "categoryId" | "priority" | "dueDate" | "plannedDate">>) {
    const current = tasks.find(task => task.id === id); const permission = current ? categoryMap.get(current.categoryId ?? "")?.permission : undefined;
    if (!user.isAdmin && permission !== "CONTRIBUTOR" && permission !== "MANAGER") { setNotice("This category is view only"); return; }
    setTasks(current => current.map(task => task.id === id ? { ...task, ...patch } : task));
    try { await api("/api/tasks", { method: "PATCH", body: JSON.stringify({ id, ...patch }) }); }
    catch (error) { setNotice(error instanceof Error ? error.message : "Unable to update task"); await load(); }
  }
  async function bulkPatch(patch: { status?: Status; categoryId?: string | null; isArchived?: boolean }) {
    if (!selected.size) return;
    try { await api("/api/tasks/bulk", { method: "PATCH", body: JSON.stringify({ ids: [...selected], ...patch }) }); setSelected(new Set()); setNotice("Selected tasks updated"); await load(); }
    catch (error) { setNotice(error instanceof Error ? error.message : "Unable to update selected tasks"); }
  }
  function applyTemplate(template: TaskTemplate) { openTaskWindow({ ...emptyDraft, title: template.title, description: template.description ?? "", priority: template.priority, status: template.status, categoryId: template.categoryId ?? "", recurrence: template.recurrence }, template.childTitles); }
  async function saveCurrentFilter() {
    const name = window.prompt("Name this filter"); if (!name?.trim()) return;
    try { await api("/api/filters", { method: "POST", body: JSON.stringify({ name, status: statusFilter === "all" ? null : statusFilter, priority: priorityFilter === "all" ? null : priorityFilter, categoryId: activeCategoryFilter === "all" ? null : activeCategoryFilter, dueWindow }) }); await loadPreferences(); setNotice("Filter saved"); }
    catch (error) { setNotice(error instanceof Error ? error.message : "Unable to save filter"); }
  }
  function applySavedFilter(filter: SavedFilter) { setStatusFilter((filter.status as Status) || "all"); setPriorityFilter((filter.priority as Priority) || "all"); setCategoryFilter(filter.categoryId || "all"); setDueWindow(filter.dueWindow); setSummaryFilter("all"); setView("all"); }

  const searchResults = tasks.filter(task => `${task.title} ${plainText(task.description)} ${categoryMap.get(task.categoryId ?? "")?.name ?? ""}`.toLowerCase().includes(query.toLowerCase()));

  return <div className={`app-shell v2-shell ${sidebarHidden ? "sidebar-hidden" : ""}`}>
    <aside className={`sidebar ${mobileNav ? "mobile-open" : ""}`}>
      <div className="brand-row"><span className="brand-mark">d</span><span className="brand-name">Digital Notebook</span><button className="sidebar-toggle" onClick={() => setSidebarHidden(true)} aria-label="Hide left menu" title="Hide left menu"><Icon name="chevron" /></button><button className="mobile-close" onClick={() => setMobileNav(false)} aria-label="Close menu"><Icon name="close" /></button></div>
      <nav className="main-nav">
        <button className={!archived && view === "dashboard" ? "active" : ""} onClick={() => openView("dashboard")}><Icon name="home" />Dashboard</button>
        <button className={!archived && view === "today" ? "active" : ""} onClick={() => openView("today")}><Icon name="sun" />Today</button>
        <button className={!archived && view === "week" ? "active" : ""} onClick={() => openView("week")}><Icon name="calendar" />This week</button>
        <button className={!archived && view === "all" ? "active" : ""} onClick={() => openView("all")}><Icon name="list" />All tasks <span className="nav-count">{displayCountTasks.length}</span></button>
        <button className={!archived && view === "calendar" ? "active" : ""} onClick={() => openView("calendar")}><Icon name="calendar" />Calendar</button>
        <button className={!archived && view === "board" ? "active" : ""} onClick={() => openView("board")}><Icon name="board" />Status board</button>
        <button className={!archived && view === "category_board" ? "active" : ""} onClick={() => openView("category_board")}><Icon name="category" />Category board</button>
        <button className={archived ? "active" : ""} onClick={() => { setArchived(true); setSummaryFilter("all"); setView("all"); }}><Icon name="archive" />Archive</button>
      </nav>
      <div className="sidebar-section">
        <div className="section-title"><span>Categories</span>{user.isAdmin && <button onClick={() => setCategoryManager(true)} aria-label="Manage categories"><Icon name="settings" /></button>}</div>
        <button className={`category-row ${activeCategoryFilter === "all" ? "selected" : ""}`} onClick={() => setCategoryFilter("all")}><span className="category-dot" /><span>All</span></button>
        {categories.map(category => <button className={`category-row ${activeCategoryFilter === category.id ? "selected" : ""}`} key={category.id} onClick={() => setCategoryFilter(category.id)}><span className="category-dot" style={{ background: category.color ?? undefined }} /><span>{category.name}</span><span className="category-count">{displayCountTasks.filter(task => task.categoryId === category.id).length}</span></button>)}
        {user.isAdmin && <button className="sidebar-add" onClick={() => setCategoryManager(true)}><Icon name="plus" /> Manage categories</button>}
      </div>
      {templates.length > 0 && <div className="sidebar-section template-shortcuts"><div className="section-title"><span>Templates</span><button onClick={() => setTemplateManager(true)} aria-label="Manage templates"><Icon name="settings" /></button></div>{templates.slice(0, 3).map(template => <button className="category-row" key={template.id} onClick={() => applyTemplate(template)}><Icon name="plus" /><span>{template.name}</span></button>)}</div>}
      <button className="quick-capture" onClick={() => startTask()}><Icon name="plus" /><span><strong>New task</strong><small>Add a task or note</small></span><kbd>⌘ N</kbd></button>
    </aside>

    {sidebarHidden && <button className="sidebar-reveal" onClick={() => setSidebarHidden(false)} aria-label="Show left menu" title="Show left menu"><Icon name="chevron" /></button>}

    <main className="workspace">
      <header className="topbar">
        <button className="mobile-menu" onClick={() => setMobileNav(true)}><Icon name="list" /></button>
        <button className="search-trigger" onClick={() => setSearchOpen(true)}><Icon name="search" /><span>Search tasks and notes…</span><kbd>⌘ K</kbd></button>
        <div className="header-actions">
          <div className="manage-wrap"><button className="manage-button" onClick={() => setManageOpen(!manageOpen)}><Icon name="settings" />Manage <Icon name="down" /></button>{manageOpen && <div className="manage-menu">{user.isAdmin && <button onClick={() => { setCategoryManager(true); setManageOpen(false); }}><Icon name="settings" /><span><strong>Categories</strong><small>Add, rename or remove</small></span></button>}<button onClick={() => { setTemplateManager(true); setManageOpen(false); }}><Icon name="list" /><span><strong>Task templates</strong><small>Reuse repeatable work</small></span></button><button onClick={() => { setGoogleManager(true); setManageOpen(false); }}><Icon name="calendar" /><span><strong>Google & reminders</strong><small>Calendar, Gmail and alerts</small></span></button><a href="/api/export?format=csv"><Icon name="file" /><span><strong>Export tasks</strong><small>Download a CSV copy</small></span></a><a href="/api/export"><Icon name="archive" /><span><strong>Backup everything</strong><small>Download a JSON backup</small></span></a>{user.isAdmin && <button onClick={() => { setAccessManager(true); setManageOpen(false); }}><Icon name="people" /><span><strong>People & category access</strong><small>Approve users and assign categories</small></span></button>}</div>}</div>
          <button className="icon-button" onClick={() => setDark(!dark)} aria-label="Toggle theme"><Icon name="sun" /></button>
          <div className="profile-wrap"><button className="avatar" onClick={() => setProfileOpen(!profileOpen)}>{user.name.slice(0, 1).toUpperCase()}</button>{profileOpen && <div className="profile-menu"><strong>{user.name}</strong><span>{user.email}</span>{user.isAdmin && <small className="admin-badge">Administrator</small>}<a href="/signout-with-chatgpt?return_to=/login">Sign out</a></div>}</div>
        </div>
      </header>

      <section className="content v2-content">
        <div className="welcome-row"><div><p className="eyebrow">{archived ? "Archive" : view === "dashboard" ? "Today at a glance" : view === "today" ? "Your daily plan" : view === "week" ? "Seven-day focus" : "Your notebook"}</p><h1>{archived ? "Past tasks" : view === "dashboard" ? `Good ${new Date().getHours() < 12 ? "morning" : "afternoon"}, ${user.name.split(" ")[0]}` : view === "today" ? "Today" : view === "week" ? "This week" : view === "calendar" ? "Calendar" : view === "all" ? summaryFilter === "TODO" ? "Not started" : summaryFilter === "IN_PROGRESS" ? "Started" : summaryFilter === "OVERDUE" ? "Overdue" : "All tasks" : view === "category_board" ? "Category board" : "Status board"}</h1></div><button className="primary-button" onClick={() => startTask({ plannedDate: view === "today" ? new Date().toISOString().slice(0, 16) : "" })}><Icon name="plus" /> New task</button></div>
        {!archived && <div className="summary-strip compact-summary" aria-label="Task filters"><button className={summaryFilter === "TODO" ? "active" : ""} onClick={() => showSummary("TODO")} aria-pressed={summaryFilter === "TODO"}><span className="summary-icon amber"><Icon name="list" /></span><span><strong>{notStartedCount}</strong><small>Not started</small></span></button><button className={summaryFilter === "IN_PROGRESS" ? "active" : ""} onClick={() => showSummary("IN_PROGRESS")} aria-pressed={summaryFilter === "IN_PROGRESS"}><span className="summary-icon violet"><Icon name="board" /></span><span><strong>{startedCount}</strong><small>Started</small></span></button><button className={summaryFilter === "OVERDUE" ? "active" : ""} onClick={() => showSummary("OVERDUE")} aria-pressed={summaryFilter === "OVERDUE"}><span className="summary-icon coral"><Icon name="calendar" /></span><span><strong>{overdueCount}</strong><small>Overdue</small></span></button><button className={summaryFilter === "all" ? "active" : ""} onClick={() => showSummary("all")} aria-pressed={summaryFilter === "all"}><span className="summary-icon green"><Icon name="category" /></span><span><strong>{displayCountTasks.length}</strong><small>All tasks</small></span></button></div>}
        <div className="v2-toolbar"><div className="view-tabs"><button className={!archived && view === "dashboard" ? "active" : ""} onClick={() => openView("dashboard")}><Icon name="home" />Dashboard</button><button className={!archived && view === "today" ? "active" : ""} onClick={() => openView("today")}><Icon name="sun" />Today</button><button className={!archived && view === "week" ? "active" : ""} onClick={() => openView("week")}><Icon name="calendar" />Week</button><button className={!archived && view === "all" ? "active" : ""} onClick={() => openView("all")}><Icon name="list" />All</button><button className={!archived && view === "calendar" ? "active" : ""} onClick={() => openView("calendar")}><Icon name="calendar" />Calendar</button><button className={!archived && view === "board" ? "active" : ""} onClick={() => openView("board")}><Icon name="board" />Status</button><button className={!archived && view === "category_board" ? "active" : ""} onClick={() => openView("category_board")}><Icon name="category" />Categories</button></div><div className={`category-filter-control ${activeCategoryFilter !== "all" ? "active" : ""}`}><span className="filter-label"><Icon name="list" />Category</span><select aria-label="Filter tasks by category" value={activeCategoryFilter} onChange={event => setCategoryFilter(event.target.value)}><option value="all">All categories</option>{categories.map(category => <option value={category.id} key={category.id}>{category.name} ({category.taskCount})</option>)}</select>{activeCategoryFilter !== "all" && <button type="button" onClick={() => setCategoryFilter("all")} aria-label="Clear category filter" title="Clear category filter"><Icon name="close" /></button>}</div></div>
        {!archived && <div className="advanced-filters"><select aria-label="Filter by status" value={statusFilter} onChange={event => setStatusFilter(event.target.value as Status | "all")}><option value="all">Any status</option><option value="TODO">Not started</option><option value="IN_PROGRESS">Started</option><option value="WAITING">Waiting</option><option value="DONE">Complete</option></select><select aria-label="Filter by priority" value={priorityFilter} onChange={event => setPriorityFilter(event.target.value as Priority | "all")}><option value="all">Any priority</option><option value="HIGH">High priority</option><option value="MEDIUM">Medium priority</option><option value="LOW">Low priority</option></select><select aria-label="Filter by due date" value={dueWindow} onChange={event => setDueWindow(event.target.value as DueWindow)}><option value="all">Any due date</option><option value="today">Due today</option><option value="week">Due this week</option><option value="overdue">Overdue</option><option value="no_date">No due date</option></select><button onClick={() => void saveCurrentFilter()}><Icon name="plus" /> Save filter</button>{(statusFilter !== "all" || priorityFilter !== "all" || dueWindow !== "all") && <button onClick={() => { setStatusFilter("all"); setPriorityFilter("all"); setDueWindow("all"); }}><Icon name="close" /> Clear</button>}{view !== "calendar" && tasks.some(task => task.seriesId) && <label className={`occurrence-toggle filter-occurrence-toggle ${showAllOccurrences ? "active" : ""}`}><input type="checkbox" checked={showAllOccurrences} onChange={event => { setShowAllOccurrences(event.target.checked); setSelected(new Set()); }} /><span>Show all occurrences</span></label>}</div>}
        {!archived && savedFilters.length > 0 && <div className="saved-filter-row"><span>Saved:</span>{savedFilters.map(filter => <span className="saved-filter-chip" key={filter.id}><button onClick={() => applySavedFilter(filter)}>{filter.name}</button><button aria-label={`Delete ${filter.name}`} onClick={async () => { await api(`/api/filters?id=${filter.id}`, { method: "DELETE" }); await loadPreferences(); }}><Icon name="close" /></button></span>)}</div>}
        {selected.size > 0 && <div className="bulk-bar"><strong>{selected.size} selected</strong><select defaultValue="" onChange={event => { if (event.target.value) void bulkPatch({ status: event.target.value as Status }); event.currentTarget.value = ""; }}><option value="">Change status…</option><option value="TODO">Not started</option><option value="IN_PROGRESS">Started</option><option value="WAITING">Waiting</option><option value="DONE">Complete</option></select><select defaultValue="" onChange={event => { if (event.target.value) void bulkPatch({ categoryId: event.target.value === "none" ? null : event.target.value }); event.currentTarget.value = ""; }}><option value="">Change category…</option><option value="none">Uncategorised</option>{categories.map(category => <option value={category.id} key={category.id}>{category.name}</option>)}</select><button onClick={() => void bulkPatch({ isArchived: !archived })}><Icon name="archive" />{archived ? "Restore" : "Archive"}</button><button onClick={() => setSelected(new Set())}>Clear</button></div>}
        {notice && <button className="notice" onClick={() => setNotice("")}>{notice}<Icon name="close" /></button>}
        {loading ? <Loading /> : visibleTasks.length === 0 && view !== "dashboard" && view !== "calendar" && view !== "today" && view !== "week" ? <Empty archived={archived} add={() => startTask()} /> : <>
          {view === "dashboard" && <Dashboard tasks={visibleTasks} calendarTasks={dashboardCalendarTasks} events={googleEvents} categories={categoryMap} edit={editTask} toggle={toggleTask} openCalendar={() => openView("calendar")} />}
          {(view === "today" || view === "week") && <FocusView view={view} tasks={visibleTasks} roots={topTasks} events={googleEvents} categories={categoryMap} expanded={expanded} setExpanded={setExpanded} selected={selected} setSelected={setSelected} edit={editTask} addChild={addChild} toggle={toggleTask} patch={quickPatch} />}
          {view === "all" && <TaskTree tasks={visibleTasks} roots={topTasks} categories={categoryMap} expanded={expanded} setExpanded={setExpanded} selected={selected} setSelected={setSelected} edit={editTask} addChild={addChild} toggle={toggleTask} patch={quickPatch} />}
          {view === "calendar" && <CalendarView tasks={visibleTasks} events={googleEvents} categories={categoryMap} edit={editTask} />}
          {view === "board" && <Board tasks={visibleTasks} categories={categoryMap} edit={editTask} toggle={toggleTask} />}
          {view === "category_board" && <CategoryBoard tasks={visibleTasks} categories={categoryMap} edit={editTask} toggle={toggleTask} />}
        </>}
      </section>
    </main>

    {taskWindows.map(item => <TaskEditor key={item.key} windowKey={item.key} draft={item.draft} tasks={tasks} categories={categories} isAdmin={user.isAdmin} position={{ x: item.x, y: item.y }} zIndex={item.z} templateChildren={item.templateChildren} close={() => closeTaskWindow(item.key)} focus={() => focusTaskWindow(item.key)} move={(x, y) => moveTaskWindow(item.key, x, y)} save={saveTask} archive={setTaskArchived} remove={deleteTask} createChild={addChild} openPrevious={openPreviousOccurrence} seriesAction={updateRecurringSeries} changed={load} />)}
    {categoryManager && <CategoryManager categories={categories} close={() => setCategoryManager(false)} changed={load} />}
    {accessManager && user.isAdmin && <AccessManager currentEmail={user.email} categories={categories} close={() => setAccessManager(false)} />}
    {templateManager && <TemplateManager templates={templates} close={() => setTemplateManager(false)} changed={loadPreferences} applyTemplate={applyTemplate} />}
    {googleManager && <GoogleManager status={googleStatus} close={() => { setGoogleManager(false); void loadPreferences(); }} />}
    {searchOpen && <SearchModal query={query} setQuery={setQuery} tasks={searchResults} categories={categoryMap} close={() => setSearchOpen(false)} open={task => { editTask(task); setSearchOpen(false); }} />}
    {mobileNav && <button className="mobile-scrim" onClick={() => setMobileNav(false)} />}
  </div>;
}

function TaskTree({ tasks, roots, categories, expanded, setExpanded, selected, setSelected, edit, addChild, toggle, patch }: { tasks: Task[]; roots: Task[]; categories: Map<string, Category>; expanded: Set<string>; setExpanded: (value: Set<string>) => void; selected: Set<string>; setSelected: (value: Set<string>) => void; edit: (task: Task) => void; addChild: (task: Task) => void; toggle: (task: Task) => void; patch: (id: string, patch: Partial<Pick<Task, "title" | "status" | "categoryId" | "priority" | "dueDate" | "plannedDate">>) => Promise<void> }) {
  const children = (id: string) => tasks.filter(task => task.parentId === id);
  const row = (task: Task, depth = 0): React.ReactNode => {
    const childTasks = children(task.id); const isOpen = expanded.has(task.id); const taskPermission = categories.get(task.categoryId ?? "")?.permission; const canEdit = taskPermission === "CONTRIBUTOR" || taskPermission === "MANAGER";
    return <div className="tree-branch" key={task.id}>
      <div className={`tree-row depth-${Math.min(depth, 3)} ${selected.has(task.id) ? "selected" : ""}`} style={{ "--depth": depth } as React.CSSProperties}>
        <input className="task-selector" type="checkbox" checked={selected.has(task.id)} onChange={() => { const next = new Set(selected); if (next.has(task.id)) next.delete(task.id); else next.add(task.id); setSelected(next); }} aria-label={`Select ${task.title}`} />
        <button className={`expand-button ${childTasks.length ? "has-children" : ""}`} onClick={() => { const next = new Set(expanded); if (isOpen) next.delete(task.id); else next.add(task.id); setExpanded(next); }} aria-label={isOpen ? "Collapse child tasks" : "Expand child tasks"}><Icon name={isOpen ? "down" : "chevron"} /></button>
        <button className={`status-ring large ${task.status.toLowerCase()}`} disabled={!canEdit} onClick={() => toggle(task)} aria-label={`Mark ${task.title} ${task.status === "DONE" ? "open" : "complete"}`}><Icon name="check" /></button>
        <div className="tree-main"><button type="button" className="inline-title" onClick={() => edit(task)} aria-label={`Open ${task.title}`}>{task.title}</button><span>{plainText(task.description) || (depth ? "Child task" : "No notes")}</span></div>
        <select className="inline-category" disabled={!canEdit} value={task.categoryId ?? ""} onChange={event => void patch(task.id, { categoryId: event.target.value || null })} aria-label={`Category for ${task.title}`}><option value="">Uncategorised</option>{[...categories.values()].filter(item => item.permission !== "VIEWER" || item.id === task.categoryId).map(item => <option value={item.id} key={item.id}>{item.name}</option>)}</select>
        <select className={`inline-status ${task.status.toLowerCase()}`} disabled={!canEdit} value={task.status} onChange={event => void patch(task.id, { status: event.target.value as Status })} aria-label={`Status for ${task.title}`}><option value="TODO">Not started</option><option value="IN_PROGRESS">Started</option><option value="WAITING">Waiting</option><option value="DONE">Complete</option></select>
        <select className="inline-priority" disabled={!canEdit} value={task.priority} onChange={event => void patch(task.id, { priority: event.target.value as Priority })} aria-label={`Priority for ${task.title}`}><option value="LOW">Low</option><option value="MEDIUM">Medium</option><option value="HIGH">High</option></select>
        <input className="inline-due" disabled={!canEdit} type="datetime-local" value={dateTimeValue(task.dueDate)} onChange={event => void patch(task.id, { dueDate: event.target.value || null })} aria-label={`Due date for ${task.title}`} />
        {canEdit ? <button className="row-action" onClick={() => addChild(task)} title="Add child task"><Icon name="plus" /></button> : <span />}
        <button className="row-action" onClick={() => edit(task)} title="Edit task"><Icon name="edit" /></button>
      </div>
      {childTasks.length > 0 && isOpen && <div className="tree-children">{childTasks.map(child => row(child, depth + 1))}</div>}
    </div>;
  };
  return <div className="task-tree"><div className="tree-head"><input type="checkbox" checked={tasks.length > 0 && tasks.every(task => selected.has(task.id))} onChange={event => setSelected(event.target.checked ? new Set(tasks.map(task => task.id)) : new Set())} aria-label="Select all visible tasks" /><span>Task</span><span>Category</span><span>Status</span><span>Priority</span><span>Due</span><span /></div>{roots.map(task => row(task))}</div>;
}

function FocusView({ view, tasks, roots, events, categories, expanded, setExpanded, selected, setSelected, edit, addChild, toggle, patch }: { view: "today" | "week"; tasks: Task[]; roots: Task[]; events: GoogleEvent[]; categories: Map<string, Category>; expanded: Set<string>; setExpanded: (value: Set<string>) => void; selected: Set<string>; setSelected: (value: Set<string>) => void; edit: (task: Task) => void; addChild: (task: Task) => void; toggle: (task: Task) => void; patch: (id: string, patch: Partial<Pick<Task, "title" | "status" | "categoryId" | "priority" | "dueDate" | "plannedDate">>) => Promise<void> }) {
  if (view === "week") return <WeekCalendar tasks={tasks} events={events} categories={categories} edit={edit} toggle={toggle} />;
  const today = sydneyDateKey(new Date()); const week = rangeForThisWeek(); const weekStart = sydneyDateKey(week.start); const weekEnd = sydneyDateKey(week.end);
  const visibleEvents = events.filter(event => view === "today" ? event.date === today : event.date >= weekStart && event.date < weekEnd);
  return <div className="focus-view">{visibleEvents.length > 0 && <section className="focus-events"><div className="panel-heading"><div><span className="eyebrow">Google Calendar</span><h2>{view === "today" ? "Today’s events" : "This week’s events"}</h2></div><strong>{visibleEvents.length}</strong></div><div>{visibleEvents.map(event => <a key={event.id} href={event.url ?? "#"} target="_blank" rel="noreferrer"><i style={{ background: event.color }} /><span><strong>{event.title}</strong><small>{new Intl.DateTimeFormat("en-AU", { weekday: view === "week" ? "short" : undefined, day: view === "week" ? "numeric" : undefined, hour: "numeric", minute: "2-digit" }).format(new Date(event.start))} · {event.calendar}</small></span></a>)}</div></section>}{tasks.length ? <TaskTree tasks={tasks} roots={roots} categories={categories} expanded={expanded} setExpanded={setExpanded} selected={selected} setSelected={setSelected} edit={edit} addChild={addChild} toggle={toggle} patch={patch} /> : <div className="focus-clear"><span className="summary-icon green"><Icon name="check" /></span><strong>{view === "today" ? "Nothing else planned for today" : "No tasks planned for this week"}</strong><small>Use “Plan for” in a task to place it here without changing its due date.</small></div>}</div>;
}

function WeekCalendar({ tasks, events, categories, edit, toggle }: { tasks: Task[]; events: GoogleEvent[]; categories: Map<string, Category>; edit: (task: Task) => void; toggle: (task: Task) => void }) {
  const { start } = rangeForThisWeek();
  const days = Array.from({ length: 7 }, (_, index) => { const day = new Date(start); day.setDate(start.getDate() + index); return day; });
  const today = sydneyDateKey(new Date());
  const weekEnd = days[6];
  const rangeLabel = `${new Intl.DateTimeFormat("en-AU", { day: "numeric", month: "short" }).format(days[0])} – ${new Intl.DateTimeFormat("en-AU", { day: "numeric", month: "short", year: "numeric" }).format(weekEnd)}`;
  const eventTime = (event: GoogleEvent) => event.start.length === 10 ? "All day" : new Intl.DateTimeFormat("en-AU", { hour: "numeric", minute: "2-digit" }).format(new Date(event.start));
  return <section className="week-calendar"><div className="week-calendar-heading"><div><span className="eyebrow">Monday to Sunday</span><h2>{rangeLabel}</h2></div><span>{tasks.length} tasks · {events.filter(event => days.some(day => event.date === sydneyDateKey(day))).length} events</span></div><div className="week-calendar-scroll"><div className="week-calendar-grid">{days.map(day => { const key = sydneyDateKey(day); const dayTasks = tasks.filter(task => task.plannedDate || task.dueDate ? dateKey(task.plannedDate || task.dueDate!) === key : false); const dayEvents = events.filter(event => event.date === key); return <section className={`week-day-column ${key === today ? "today" : ""}`} key={key}><header><span>{new Intl.DateTimeFormat("en-AU", { weekday: "short" }).format(day)}</span><strong>{day.getDate()}</strong></header><div className="week-day-items">{dayEvents.map(event => <a className="week-event-card" href={event.url ?? "#"} target="_blank" rel="noreferrer" key={event.id} style={{ "--week-color": event.color } as React.CSSProperties}><small>{eventTime(event)}</small><strong>{event.title}</strong><span>{event.calendar}</span></a>)}{dayTasks.map(task => <article className="week-task-card" key={task.id} style={{ "--week-color": categories.get(task.categoryId ?? "")?.color ?? "#6556a5" } as React.CSSProperties}><button className="week-task-main" onClick={() => edit(task)}><small>{task.plannedDate ? "Planned" : "Due"}</small><strong>{task.title}</strong><span>{categories.get(task.categoryId ?? "")?.name ?? "Uncategorised"}</span></button><button className={`status-ring ${task.status.toLowerCase()}`} onClick={() => toggle(task)} aria-label={`Mark ${task.title} ${task.status === "DONE" ? "open" : "complete"}`}><Icon name="check" /></button></article>)}{dayEvents.length === 0 && dayTasks.length === 0 && <span className="week-day-empty">No items</span>}</div></section>; })}</div></div></section>;
}

function Dashboard({ tasks, calendarTasks, events, categories, edit, toggle, openCalendar }: { tasks: Task[]; calendarTasks: Task[]; events: GoogleEvent[]; categories: Map<string, Category>; edit: (task: Task) => void; toggle: (task: Task) => void; openCalendar: () => void }) {
  const now = new Date(); const today = new Date(now.getFullYear(), now.getMonth(), now.getDate()); const soon = new Date(today); soon.setDate(soon.getDate() + 7);
  const overdue = tasks.filter(task => task.status !== "DONE" && task.dueDate && new Date(task.dueDate) < today).sort((a,b) => a.dueDate!.localeCompare(b.dueDate!));
  const upcoming = tasks.filter(task => task.status !== "DONE" && task.dueDate && new Date(task.dueDate) >= today && new Date(task.dueDate) <= soon).sort((a,b) => a.dueDate!.localeCompare(b.dueDate!));
  const urgent = [...overdue, ...upcoming].filter(task => task.priority === "HIGH" || overdue.includes(task)).slice(0, 5);
  return <div className="dashboard-grid">
    <section className="dashboard-calendar"><div className="panel-heading"><div><span className="eyebrow">Calendar</span><h2>This month</h2></div><button onClick={openCalendar}>Open calendar <Icon name="chevron" /></button></div><CalendarMonth tasks={calendarTasks} events={events} categories={categories} edit={edit} compact /></section>
    <aside className="dashboard-rail">
      <section className="attention-panel overdue-panel"><div className="panel-heading"><div><span className="eyebrow">Needs attention</span><h2>Overdue</h2></div><strong>{overdue.length}</strong></div><DashboardTaskList tasks={overdue.slice(0,4)} categories={categories} edit={edit} toggle={toggle} empty="Nothing overdue — nicely done." /></section>
      <section className="attention-panel"><div className="panel-heading"><div><span className="eyebrow">Next seven days</span><h2>Coming up</h2></div><strong>{upcoming.length}</strong></div><DashboardTaskList tasks={(urgent.length ? urgent : upcoming).slice(0,5)} categories={categories} edit={edit} toggle={toggle} empty="No tasks due this week." /></section>
    </aside>
  </div>;
}

function DashboardTaskList({ tasks, categories, edit, toggle, empty }: { tasks: Task[]; categories: Map<string, Category>; edit: (task: Task) => void; toggle: (task: Task) => void; empty: string }) {
  if (!tasks.length) return <p className="panel-empty">{empty}</p>;
  return <div className="dashboard-task-list">{tasks.map(task => <div key={task.id}><button className={`status-ring ${task.status.toLowerCase()}`} onClick={() => toggle(task)}><Icon name="check" /></button><button onClick={() => edit(task)}><strong>{task.title}</strong><small>{formatDue(task.dueDate)} · {categories.get(task.categoryId ?? "")?.name ?? "Uncategorised"}</small></button><span className={`priority-mark ${task.priority.toLowerCase()}`} /></div>)}</div>;
}

function CalendarView({ tasks, events, categories, edit }: { tasks: Task[]; events: GoogleEvent[]; categories: Map<string, Category>; edit: (task: Task) => void }) { return <CalendarMonth tasks={tasks} events={events} categories={categories} edit={edit} />; }

function CalendarMonth({ tasks, events, categories, edit, compact = false }: { tasks: Task[]; events: GoogleEvent[]; categories: Map<string, Category>; edit: (task: Task) => void; compact?: boolean }) {
  const [cursor, setCursor] = useState(() => { const dated = tasks.find(task => task.dueDate); return compact || !dated ? new Date() : new Date(dated.dueDate!); });
  const year = cursor.getUTCFullYear(); const month = cursor.getUTCMonth(); const first = new Date(Date.UTC(year, month, 1)); const start = new Date(first); start.setUTCDate(1 - ((first.getUTCDay() + 6) % 7));
  const days = Array.from({ length: 42 }, (_, index) => { const day = new Date(start); day.setUTCDate(start.getUTCDate() + index); return day; });
  const dayTasks = (day: Date) => tasks.filter(task => task.dueDate && new Date(task.dueDate).toISOString().slice(0,10) === day.toISOString().slice(0,10));
  const dayEvents = (day: Date) => events.filter(event => event.date === day.toISOString().slice(0,10));
  const move = (amount: number) => setCursor(new Date(Date.UTC(year, month + amount, 1)));
  return <div className={`month-calendar ${compact ? "compact" : ""}`}><div className="month-toolbar"><button onClick={() => move(-1)} aria-label="Previous month">‹</button><strong>{new Intl.DateTimeFormat("en-AU", { month: "long", year: "numeric", timeZone: "UTC" }).format(first)}</strong><button onClick={() => move(1)} aria-label="Next month">›</button></div><div className="month-weekdays">{["Mon","Tue","Wed","Thu","Fri","Sat","Sun"].map(day => <span key={day}>{day}</span>)}</div><div className="month-grid">{days.map(day => { const items = dayTasks(day); const external = dayEvents(day); const outside = day.getUTCMonth() !== month; const today = day.toISOString().slice(0,10) === new Date().toISOString().slice(0,10); const limit = compact ? 2 : 4; return <div className={`month-day ${outside ? "outside" : ""} ${today ? "today" : ""}`} key={day.toISOString()}><span className="day-number">{day.getUTCDate()}</span><div className="month-tasks">{external.slice(0, limit).map(event => <a className="google-calendar-event" href={event.url ?? "#"} target="_blank" rel="noreferrer" key={event.id} style={{ "--task-color": event.color } as React.CSSProperties}><strong>{event.title}</strong>{!compact && <small>{event.calendar}</small>}</a>)}{items.slice(0, Math.max(0, limit - external.length)).map(task => <button key={task.id} onClick={() => edit(task)} style={{ "--task-color": categories.get(task.categoryId ?? "")?.color ?? "#6556a5" } as React.CSSProperties}><strong>{task.title}</strong>{!compact && <small>{formatDue(task.dueDate)}</small>}</button>)}{items.length + external.length > limit && <span className="more-tasks">+{items.length + external.length - limit} more</span>}</div></div>; })}</div></div>;
}

function Board({ tasks, categories, edit, toggle }: { tasks: Task[]; categories: Map<string, Category>; edit: (task: Task) => void; toggle: (task: Task) => void }) {
  const columns: { status: Status; label: string; color: string }[] = [
    { status: "TODO", label: "Not started", color: "#b37a3e" },
    { status: "IN_PROGRESS", label: "Started", color: "#6556a5" },
    { status: "WAITING", label: "Waiting", color: "#557f95" },
    { status: "DONE", label: "Complete", color: "#5f846a" },
  ];
  return <div className="board-grid status-board-grid">{columns.map(column => <section className="board-column status-board-column" key={column.status} style={{ "--status-color": column.color } as React.CSSProperties}><div className="board-heading"><span><i className="board-dot" />{column.label}</span><small>{tasks.filter(task => task.status === column.status).length}</small></div><div className="board-stack">{tasks.filter(task => task.status === column.status).map(task => <article className="board-card status-board-card" key={task.id}><button onClick={() => edit(task)}><span className="child-label">{task.parentId ? "Child task" : "Task"}</span><strong>{task.title}</strong><small>{formatDue(task.dueDate)} · {categories.get(task.categoryId ?? "")?.name ?? "Uncategorised"}</small></button><button className="board-complete" onClick={() => toggle(task)}>{task.status === "DONE" ? "Reopen" : "Mark complete"}</button></article>)}</div></section>)}</div>;
}

function CategoryBoard({ tasks, categories, edit, toggle }: { tasks: Task[]; categories: Map<string, Category>; edit: (task: Task) => void; toggle: (task: Task) => void }) {
  const groups = [...categories.values()].filter(category => tasks.some(task => task.categoryId === category.id)).map(category => ({ id: category.id, label: category.name, color: category.color ?? "#6556a5" }));
  if (tasks.some(task => !task.categoryId || !categories.has(task.categoryId))) groups.push({ id: "uncategorised", label: "Uncategorised", color: "#9da098" });
  const groupTasks = (id: string) => tasks.filter(task => id === "uncategorised" ? !task.categoryId || !categories.has(task.categoryId) : task.categoryId === id);
  const statusLabel: Record<Status, string> = { TODO: "Not started", IN_PROGRESS: "Started", WAITING: "Waiting", DONE: "Complete" };
  return <div className="board-grid category-board-grid">{groups.map(group => { const items = groupTasks(group.id); return <section className="board-column category-board-column" key={group.id} style={{ "--category-color": group.color } as React.CSSProperties}><div className="board-heading"><span><i className="board-dot" style={{ background: group.color }} />{group.label}</span><small>{items.length}</small></div><div className="board-stack">{items.map(task => <article className="board-card category-board-card" key={task.id}><button onClick={() => edit(task)}><span className="category-card-meta"><i className={`status-mini ${task.status.toLowerCase()}`} />{statusLabel[task.status]} · {task.priority.toLowerCase()}</span><strong>{task.title}</strong><small>{formatDue(task.dueDate)}{task.parentId ? " · Child task" : ""}</small></button><button className="board-complete" onClick={() => toggle(task)}>{task.status === "DONE" ? "Reopen" : "Mark complete"}</button></article>)}</div></section>; })}</div>;
}

function TaskEditor({ windowKey, draft: initial, tasks, categories, isAdmin, position, zIndex, templateChildren, close, focus, move, save, archive, remove, createChild, openPrevious, seriesAction, changed }: { windowKey: string; draft: TaskDraft; tasks: Task[]; categories: Category[]; isAdmin: boolean; position: { x: number; y: number }; zIndex: number; templateChildren: string[]; close: () => void; focus: () => void; move: (x: number, y: number) => void; save: (windowKey: string, draft: TaskDraft, templateChildren: string[], editScope: "occurrence" | "series") => Promise<void>; archive: (windowKey: string, id: string, isArchived: boolean) => Promise<void>; remove: (windowKey: string, id: string) => Promise<void>; createChild: (task: Task) => void; openPrevious: (taskId: string) => Promise<void>; seriesAction: (taskId: string, action: "pause" | "resume" | "delete") => Promise<void>; changed: () => Promise<void> }) {
  const [draft, setDraft] = useState(initial); const [saving, setSaving] = useState(false); const [error, setError] = useState(""); const [seriesMessage, setSeriesMessage] = useState(""); const [editScope, setEditScope] = useState<"occurrence" | "series">("occurrence"); const [availableCategories, setAvailableCategories] = useState(categories); const [categoryCreator, setCategoryCreator] = useState(false); const [newCategoryName, setNewCategoryName] = useState(""); const [newCategoryColor, setNewCategoryColor] = useState(colours[0]); const [categorySaving, setCategorySaving] = useState(false);
  const parent = tasks.find(task => task.id === draft.parentId); const currentTask = tasks.find(task => task.id === draft.id); const children = tasks.filter(task => task.parentId === draft.id); const currentPermission = availableCategories.find(category => category.id === draft.categoryId)?.permission; const canEdit = isAdmin || currentPermission === "CONTRIBUTOR" || currentPermission === "MANAGER"; const canManage = isAdmin || currentPermission === "MANAGER";
  async function submit(event: FormEvent) { event.preventDefault(); if (!draft.title.trim()) return setError("Give this task a title"); if (draft.recurrence !== "NONE" && !draft.dueDate) return setError("Choose a due date and time for a repeating task"); setSaving(true); try { await save(windowKey, draft, templateChildren, editScope); } catch (reason) { setError(reason instanceof Error ? reason.message : "Unable to save"); setSaving(false); } }
  function beginDrag(event: React.PointerEvent<HTMLDivElement>) {
    if (event.button !== 0 || (event.target as HTMLElement).closest("button")) return;
    event.preventDefault(); event.stopPropagation(); focus();
    const startX = event.clientX; const startY = event.clientY; const originX = position.x; const originY = position.y;
    const drag = (next: globalThis.PointerEvent) => {
      const width = Math.min(560, window.innerWidth - 32); const maxX = Math.max(8, window.innerWidth - width - 8); const maxY = Math.max(8, window.innerHeight - 80);
      move(Math.min(maxX, Math.max(8, originX + next.clientX - startX)), Math.min(maxY, Math.max(8, originY + next.clientY - startY)));
    };
    const stop = () => { window.removeEventListener("pointermove", drag); window.removeEventListener("pointerup", stop); };
    window.addEventListener("pointermove", drag); window.addEventListener("pointerup", stop, { once: true });
  }
  async function createInlineCategory() {
    const name = newCategoryName.trim(); if (!name) return setError("Give the new category a name");
    setCategorySaving(true); setError("");
    try {
      const data = await api<{ category: Category }>("/api/categories", { method: "POST", body: JSON.stringify({ name, color: newCategoryColor }) });
      setAvailableCategories(current => [...current, data.category].sort((a, b) => a.name.localeCompare(b.name)));
      setDraft(current => ({ ...current, categoryId: data.category.id })); setNewCategoryName(""); setNewCategoryColor(colours[0]); setCategoryCreator(false);
    } catch (reason) { setError(reason instanceof Error ? reason.message : "Unable to add category"); }
    finally { setCategorySaving(false); }
  }
  async function saveAsTemplate() {
    const name = window.prompt("Template name", draft.title); if (!name?.trim() || !draft.title.trim()) return;
    try { await api("/api/templates", { method: "POST", body: JSON.stringify({ name, title: draft.title, description: draft.description, priority: draft.priority, status: draft.status, categoryId: draft.categoryId || null, recurrence: draft.recurrence, childTitles: children.map(child => child.title) }) }); setError("Template saved. It is now available from the left menu."); }
    catch (reason) { setError(reason instanceof Error ? reason.message : "Unable to save template"); }
  }
  async function carryForward() {
    if (!currentTask) return;
    setSeriesMessage(""); setError("");
    try {
      const data = await api<{ task: Task; addedChildren: number; addedFiles: number; message: string }>("/api/recurrence", { method: "POST", body: JSON.stringify({ taskId: currentTask.id, action: "carry" }) });
      setDraft(current => ({ ...current, description: data.task.description ?? current.description }));
      const additions = [data.addedChildren ? `${data.addedChildren} child task${data.addedChildren === 1 ? "" : "s"}` : "", data.addedFiles ? `${data.addedFiles} file${data.addedFiles === 1 ? "" : "s"}` : ""].filter(Boolean);
      setSeriesMessage(`${data.message}${additions.length ? ` (${additions.join(", ")})` : ""}.`);
      await changed();
    } catch (reason) { setError(reason instanceof Error ? reason.message : "Unable to carry forward the previous occurrence"); }
  }
  return <div className="task-window" style={{ left: position.x, top: position.y, zIndex }} onPointerDown={focus}><aside className="task-drawer editor-drawer"><form onSubmit={submit}>
    <div className="drawer-top task-window-handle" onPointerDown={beginDrag}><div><span className="eyebrow">{draft.id ? "Edit task" : draft.parentId ? "New child task" : "New task"}</span>{parent && <small className="parent-path">Under {parent.title}</small>}</div><span className="window-drag-hint"><Icon name="more" /> Drag to move</span><button type="button" className="icon-button" onClick={close} aria-label="Close task window"><Icon name="close" /></button></div>
    <fieldset className="drawer-content editor-fields" disabled={!canEdit}>
      {!canEdit && <div className="access-note"><Icon name="lock" /><span>View only — ask an administrator for contributor access to edit this category.</span></div>}
      <label>Task title<input className="editor-title-input" autoFocus value={draft.title} onChange={event => setDraft({ ...draft, title: event.target.value })} placeholder="What needs to be done?" /></label>
      <div className="field-grid"><label>Due date &amp; time<input type="datetime-local" value={draft.dueDate} onChange={event => setDraft({ ...draft, dueDate: event.target.value })} /></label><label>Plan for<input type="datetime-local" value={draft.plannedDate} onChange={event => setDraft({ ...draft, plannedDate: event.target.value })} /></label><label>Reminder<input type="datetime-local" value={draft.reminderAt} onChange={event => setDraft({ ...draft, reminderAt: event.target.value })} /></label><label>Repeat<select disabled={Boolean(currentTask?.seriesId && editScope === "occurrence")} value={draft.recurrence} onChange={event => setDraft({ ...draft, recurrence: event.target.value as Recurrence })}><option value="NONE">Does not repeat</option><option value="DAILY">Daily</option><option value="WEEKLY">Weekly</option><option value="MONTHLY">Monthly</option></select></label><label>Status<select value={draft.status} onChange={event => setDraft({ ...draft, status: event.target.value as Status })}><option value="TODO">Not started</option><option value="IN_PROGRESS">Started</option><option value="WAITING">Waiting</option><option value="DONE">Complete</option></select></label><label>Priority<select value={draft.priority} onChange={event => setDraft({ ...draft, priority: event.target.value as Priority })}><option value="LOW">Low</option><option value="MEDIUM">Medium</option><option value="HIGH">High</option></select></label><div className="inline-category-field"><span>Category</span><div className="category-select-row"><select value={draft.categoryId} onChange={event => setDraft({ ...draft, categoryId: event.target.value })}>{isAdmin && <option value="">Uncategorised</option>}{availableCategories.filter(category => category.permission !== "VIEWER" || category.id === draft.categoryId).map(category => <option value={category.id} key={category.id}>{category.name}</option>)}</select>{isAdmin && <button type="button" className="category-add-button" onClick={() => setCategoryCreator(current => !current)} aria-expanded={categoryCreator}><Icon name="plus" /> New</button>}</div>{categoryCreator && <div className="inline-category-create"><input autoFocus value={newCategoryName} onChange={event => setNewCategoryName(event.target.value)} onKeyDown={event => { if (event.key === "Enter") { event.preventDefault(); void createInlineCategory(); } }} placeholder="New category name" /><div className="inline-colours">{colours.map(item => <button type="button" key={item} className={newCategoryColor === item ? "active" : ""} style={{ background: item }} onClick={() => setNewCategoryColor(item)} aria-label={`Use ${item}`} />)}</div><div><button type="button" className="text-button" onClick={() => { setCategoryCreator(false); setNewCategoryName(""); }}>Cancel</button><button type="button" className="secondary-button" disabled={categorySaving} onClick={() => void createInlineCategory()}>{categorySaving ? "Adding…" : "Add category"}</button></div></div>}</div></div>
      {currentTask?.seriesId && <section className="recurring-series-panel"><div className="recurring-series-heading"><span><Icon name="calendar" /><strong>{currentTask.recurrence.toLowerCase()} recurring series</strong></span><small className={currentTask.seriesDeleted ? "ended" : currentTask.seriesPaused ? "paused" : "active"}>{currentTask.seriesDeleted ? "Ended" : currentTask.seriesPaused ? "Paused" : "Active"}</small></div><p>Each occurrence is a fresh task. Notes, child tasks, files and completion remain independent.</p>{!currentTask.seriesDeleted && <label className="series-edit-scope">Apply edits to<select value={editScope} onChange={event => setEditScope(event.target.value as "occurrence" | "series")}><option value="occurrence">This occurrence only</option><option value="series">This and future occurrences</option></select></label>}<div className="series-actions">{currentTask.hasPreviousOccurrence && <button type="button" onClick={() => void openPrevious(currentTask.id)}>View previous occurrence</button>}{currentTask.hasPreviousOccurrence && canEdit && <button type="button" onClick={() => void carryForward()}>Carry forward notes, files &amp; unfinished child tasks</button>}{!currentTask.seriesDeleted && canEdit && <button type="button" onClick={() => void seriesAction(currentTask.id, currentTask.seriesPaused ? "resume" : "pause")}>{currentTask.seriesPaused ? "Resume series" : "Pause series"}</button>}{!currentTask.seriesDeleted && canManage && <button type="button" className="series-delete" onClick={() => { if (confirm("Delete this recurring series? Existing task history will be preserved.")) void seriesAction(currentTask.id, "delete"); }}>Delete series</button>}</div>{seriesMessage && <small className="series-message">{seriesMessage}</small>}</section>}
      <label>Parent task<select value={draft.parentId} onChange={event => setDraft({ ...draft, parentId: event.target.value })}><option value="">None — top-level task</option>{tasks.filter(task => task.id !== draft.id && task.parentId !== draft.id).map(task => <option value={task.id} key={task.id}>{task.title}</option>)}</select></label>
      <RichNotes value={draft.description} disabled={!canEdit} onChange={description => setDraft({ ...draft, description })} />
      {currentTask && <section className="child-editor-section"><div className="drawer-section-head"><h3>Child tasks</h3><span>{children.length}</span></div>{children.map(child => <div className="child-editor-row" key={child.id}><span className={`status-ring ${child.status.toLowerCase()}`}><Icon name="check" /></span><span><strong>{child.title}</strong><small>{formatDue(child.dueDate)}</small></span></div>)}{canEdit && <button type="button" className="add-child-inside" onClick={() => createChild(currentTask)}><Icon name="plus" /> Add child task</button>}</section>}
      {draft.id ? <AttachmentSection taskId={draft.id} /> : <div className="attachment-save-hint"><Icon name="attachment" /><span>Save this task first, then you can attach documents, PDFs, and images.</span></div>}
      {draft.id ? <GmailSection taskId={draft.id} /> : <div className="gmail-save-hint"><Icon name="mail" /><span>Save this task first, then you can link Gmail messages.</span></div>}
      {error && <p className="form-error">{error}</p>}
    </fieldset>
    <div className="drawer-footer"><div>{draft.id && canManage && <button type="button" className="danger-button" onClick={() => { if (confirm("Permanently delete this task and all of its child tasks?")) void remove(windowKey, draft.id!); }}><Icon name="trash" />Delete</button>}{currentTask && canManage && <button type="button" className="archive-button" onClick={() => { if (currentTask.isArchived || confirm("Move this task and all of its child tasks to Archive?")) void archive(windowKey, currentTask.id, !currentTask.isArchived); }}><Icon name="archive" />{currentTask.isArchived ? "Restore" : "Archive"}</button>}{canEdit && <button type="button" className="text-button template-save-button" onClick={() => void saveAsTemplate()}><Icon name="list" />Save as template</button>}</div><div><button type="button" className="secondary-button" onClick={close}>{canEdit ? "Cancel" : "Close"}</button>{canEdit && <button className="primary-button" disabled={saving}>{saving ? "Saving…" : "Save task"}</button>}</div></div>
  </form></aside></div>;
}

function RichNotes({ value, disabled = false, onChange }: { value: string; disabled?: boolean; onChange: (value: string) => void }) {
  const editor = useRef<HTMLDivElement>(null);
  useEffect(() => { if (editor.current && editor.current.innerHTML !== value) editor.current.innerHTML = value; }, [value]);
  const sync = () => onChange(editor.current?.innerHTML ?? "");
  const command = (name: string) => { editor.current?.focus(); document.execCommand(name); sync(); };
  const selectionIsInList = () => {
    const anchor = window.getSelection()?.anchorNode;
    const element = anchor instanceof Element ? anchor : anchor?.parentElement;
    const item = element?.closest("li");
    return Boolean(item && editor.current?.contains(item));
  };
  return <div className="rich-notes"><span className="field-label">Notes</span><div className="rich-toolbar"><button type="button" disabled={disabled} onClick={() => command("bold")} title="Bold"><strong>B</strong></button><button type="button" disabled={disabled} onClick={() => command("insertUnorderedList")} title="Bullet list">• List</button><button type="button" disabled={disabled} onClick={() => command("indent")} title="Indent (Tab)">→ Indent</button><button type="button" disabled={disabled} onClick={() => command("outdent")} title="Outdent (Shift+Tab)">←</button></div><div ref={editor} className="rich-editor" role="textbox" aria-label="Task notes" aria-multiline="true" contentEditable={!disabled} suppressContentEditableWarning onKeyDown={event => { if (event.key === "Enter") { event.preventDefault(); document.execCommand(selectionIsInList() ? "insertParagraph" : "insertLineBreak"); sync(); } else if (event.key === "Tab" && selectionIsInList()) { event.preventDefault(); document.execCommand(event.shiftKey ? "outdent" : "indent"); sync(); } }} onInput={event => onChange(event.currentTarget.innerHTML)} data-placeholder="Add context, links, or a short checklist…" /></div>;
}

function AttachmentSection({ taskId }: { taskId: string }) {
  const [attachments, setAttachments] = useState<Attachment[]>([]); const [uploading, setUploading] = useState(""); const [error, setError] = useState(""); const input = useRef<HTMLInputElement>(null);
  const load = useCallback(async () => { try { const data = await api<{ attachments: Attachment[] }>(`/api/attachments?taskId=${encodeURIComponent(taskId)}`); setAttachments(data.attachments); } catch (reason) { setError(reason instanceof Error ? reason.message : "Unable to load attachments"); } }, [taskId]);
  useEffect(() => { const timer = window.setTimeout(() => void load(), 0); return () => window.clearTimeout(timer); }, [load]);
  async function upload(files: FileList | null) {
    if (!files?.length) return; setError("");
    const oversized = Array.from(files).find(file => file.size > 20 * 1024 * 1024);
    if (oversized) { setError(`${oversized.name} is too large. Attach files up to 20 MB each.`); if (input.current) input.current.value = ""; return; }
    try {
      for (let index = 0; index < files.length; index += 1) {
        setUploading(`Uploading ${index + 1} of ${files.length}…`);
        const form = new FormData(); form.append("taskId", taskId); form.append("file", files[index]);
        const response = await fetch("/api/attachments", { method: "POST", body: form });
        const responseText = await response.text();
        let message = "";
        try { message = (JSON.parse(responseText) as { error?: string }).error ?? ""; } catch { message = responseText.trim(); }
        if (!response.ok) throw new Error(response.status === 413 ? "This file is too large. Attach files up to 20 MB each." : message || "Unable to upload file");
      }
      await load();
    } catch (reason) { setError(reason instanceof Error ? reason.message : "Unable to upload file"); }
    finally { setUploading(""); if (input.current) input.current.value = ""; }
  }
  const fileSize = (value: number) => value < 1024 * 1024 ? `${Math.max(1, Math.round(value / 1024))} KB` : `${(value / (1024 * 1024)).toFixed(1)} MB`;
  const canPreview = (attachment: Attachment) => attachment.contentType === "application/pdf" || /^image\/(jpeg|png|gif|webp)$/.test(attachment.contentType);
  return <section className="attachment-section"><div className="drawer-section-head"><h3>Attachments</h3><span>{attachments.length}</span></div>{attachments.length > 0 && <div className="attachment-list">{attachments.map(attachment => <article className="attachment-card" key={attachment.id}>{/^image\/(jpeg|png|gif|webp)$/.test(attachment.contentType) ? <span className="attachment-thumbnail" style={{ backgroundImage: `url(/api/attachments?id=${encodeURIComponent(attachment.id)})` }} /> : <span className="attachment-file-mark"><Icon name={attachment.contentType === "application/pdf" ? "file" : "attachment"} /></span>}<span><strong>{attachment.fileName}</strong><small>{fileSize(attachment.size)}</small><a href={`/api/attachments?id=${encodeURIComponent(attachment.id)}`} target="_blank" rel="noreferrer">{canPreview(attachment) ? "Open" : "Download"} ↗</a></span><button type="button" onClick={async () => { if (!confirm(`Remove ${attachment.fileName}?`)) return; try { await api(`/api/attachments?id=${encodeURIComponent(attachment.id)}`, { method: "DELETE" }); await load(); } catch (reason) { setError(reason instanceof Error ? reason.message : "Unable to remove attachment"); } }} aria-label={`Remove ${attachment.fileName}`}><Icon name="close" /></button></article>)}</div>}<input ref={input} className="attachment-input" type="file" multiple accept=".pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.txt,.rtf,.csv,.md,.zip,image/jpeg,image/png,image/gif,image/webp" onChange={event => void upload(event.target.files)} /><button type="button" className="attachment-upload-button" disabled={Boolean(uploading)} onClick={() => input.current?.click()}><Icon name="attachment" />{uploading || "Attach files"}</button><small className="attachment-help">Documents, PDFs, spreadsheets, presentations, text files, archives, and images up to 20 MB each.</small>{error && <p className="form-error">{error}</p>}</section>;
}

function GmailSection({ taskId }: { taskId: string }) {
  const [links, setLinks] = useState<GmailLink[]>([]); const [url, setUrl] = useState(""); const [error, setError] = useState(""); const [linking, setLinking] = useState(false); const [mailQuery, setMailQuery] = useState(""); const [results, setResults] = useState<GmailLink[]>([]);
  const load = useCallback(async () => { try { const data = await api<{ links: GmailLink[] }>(`/api/gmail/links?taskId=${encodeURIComponent(taskId)}`); setLinks(data.links); } catch (reason) { setError(reason instanceof Error ? reason.message : "Unable to load linked mail"); } }, [taskId]);
  useEffect(() => { const timer = window.setTimeout(() => void load(), 0); return () => window.clearTimeout(timer); }, [load]);
  async function linkEmail() {
    if (!url.trim()) return;
    setLinking(true); setError("");
    try {
      let details: Partial<GmailLink> = {};
      try { details = await api<Partial<GmailLink>>("/api/gmail/fetch", { method: "POST", body: JSON.stringify({ url }) }); } catch { /* A saved reference remains useful before Gmail OAuth is connected. */ }
      await api("/api/gmail/links", { method: "POST", body: JSON.stringify({ taskId, url, subject: details.subject, sender: details.sender, snippet: details.snippet, receivedAt: details.receivedAt }) });
      setUrl(""); await load();
    } catch (reason) { setError(reason instanceof Error ? reason.message : "Unable to link this Gmail message"); }
    finally { setLinking(false); }
  }
  async function searchEmail() {
    if (!mailQuery.trim()) return;
    setError("");
    try { const data = await api<{ messages: GmailLink[] }>(`/api/gmail/search?q=${encodeURIComponent(mailQuery)}`); setResults(data.messages); }
    catch (reason) { setError(reason instanceof Error ? reason.message : "Unable to search Gmail"); }
  }
  async function linkResult(message: GmailLink) { setLinking(true); setError(""); try { await api("/api/gmail/links", { method: "POST", body: JSON.stringify({ taskId, url: message.gmailUrl, subject: message.subject, sender: message.sender, snippet: message.snippet, receivedAt: message.receivedAt }) }); setResults([]); setMailQuery(""); await load(); } catch (reason) { setError(reason instanceof Error ? reason.message : "Unable to link email"); } finally { setLinking(false); } }
  return <section className="gmail-section"><div className="drawer-section-head"><h3>Linked Gmail</h3><span>{links.length}</span></div>{links.map(link => <article className="gmail-link-card" key={link.id}><span className="gmail-mark">G</span><div><strong>{link.subject}</strong><span>{link.sender}</span><p>{link.snippet}</p><a href={link.gmailUrl ?? `https://mail.google.com/mail/u/0/#inbox/${link.messageId}`} target="_blank" rel="noreferrer">Open in Gmail ↗</a></div><button type="button" onClick={async () => { await api(`/api/gmail/links?id=${link.id}`, { method: "DELETE" }); await load(); }} aria-label="Remove linked email"><Icon name="close" /></button></article>)}<div className="gmail-search-form"><input value={mailQuery} onChange={event => setMailQuery(event.target.value)} onKeyDown={event => { if (event.key === "Enter") { event.preventDefault(); void searchEmail(); } }} placeholder="Search recent Gmail" /><button type="button" className="secondary-button" disabled={linking || !mailQuery.trim()} onClick={() => void searchEmail()}>Search</button></div>{results.length > 0 && <div className="gmail-search-results">{results.map(message => <button type="button" key={message.id} disabled={linking} onClick={() => void linkResult(message)}><strong>{message.subject}</strong><span>{message.sender}</span><small>{message.snippet}</small></button>)}</div>}<div className="gmail-link-form"><input value={url} onChange={event => setUrl(event.target.value)} onKeyDown={event => { if (event.key === "Enter") { event.preventDefault(); void linkEmail(); } }} placeholder="Or paste a Gmail message URL" /><button type="button" className="secondary-button" disabled={linking || !url.trim()} onClick={() => void linkEmail()}>{linking ? "Linking…" : "Link email"}</button></div>{error && <p className="form-error">{error} {error.toLowerCase().includes("connect") && <a href="/api/google/connect">Connect Google</a>}</p>}<small className="gmail-help">Search works when Google is connected. Pasted links are always preserved with the task.</small></section>;
}

function TemplateManager({ templates, close, changed, applyTemplate }: { templates: TaskTemplate[]; close: () => void; changed: () => Promise<void>; applyTemplate: (template: TaskTemplate) => void }) {
  const [error, setError] = useState("");
  return <Modal title="Task templates" subtitle="Start repeatable work with the same structure and settings." close={close}><div className="manager-form"><div className="access-note"><Icon name="list" /><span>Open any task and choose “Save as template” to add it here, including its child-task titles.</span></div><div className="manager-list template-list">{templates.map(template => <div key={template.id}><span className="template-mark"><Icon name="list" /></span><span><strong>{template.name}</strong><small>{template.title} · {template.childTitles.length} child {template.childTitles.length === 1 ? "task" : "tasks"}</small></span><button type="button" onClick={() => { applyTemplate(template); close(); }} title={`Use ${template.name}`}><Icon name="plus" /></button><button type="button" onClick={async () => { try { await api(`/api/templates?id=${template.id}`, { method: "DELETE" }); await changed(); } catch (reason) { setError(reason instanceof Error ? reason.message : "Unable to remove template"); } }} title={`Delete ${template.name}`}><Icon name="trash" /></button></div>)}</div>{templates.length === 0 && <p className="panel-empty">No templates yet. Save one from a task.</p>}{error && <p className="form-error">{error}</p>}</div></Modal>;
}

function GoogleManager({ status, close }: { status: GoogleStatus; close: () => void }) {
  const [calendars, setCalendars] = useState<GoogleCalendar[]>([]); const [error, setError] = useState(""); const [saving, setSaving] = useState(false);
  useEffect(() => { if (!status.connected) return; const timer = window.setTimeout(() => void api<{ calendars: GoogleCalendar[] }>("/api/google/calendars").then(data => setCalendars(data.calendars)).catch(reason => setError(reason instanceof Error ? reason.message : "Unable to load calendars")), 0); return () => window.clearTimeout(timer); }, [status.connected]);
  async function saveCalendars() { setSaving(true); try { await api("/api/google/calendars", { method: "PATCH", body: JSON.stringify({ ids: calendars.filter(item => item.enabled).map(item => item.calendarId) }) }); close(); } catch (reason) { setError(reason instanceof Error ? reason.message : "Unable to save calendars"); } finally { setSaving(false); } }
  return <Modal title="Google & reminders" subtitle="Use selected calendars and Gmail inside your notebook." close={close}><div className="manager-form">{status.connected ? <><div className="integration-status connected"><span className="google-g">G</span><span><strong>Google connected</strong><small>Calendar and Gmail read-only access</small></span><button className="text-button" onClick={async () => { await api("/api/google/status", { method: "DELETE" }); close(); }}>Disconnect</button></div><div className="calendar-picker"><p className="eyebrow">Calendars shown in Digital Notebook</p>{calendars.map(calendar => <label key={calendar.calendarId}><input type="checkbox" checked={calendar.enabled} onChange={event => setCalendars(current => current.map(item => item.calendarId === calendar.calendarId ? { ...item, enabled: event.target.checked } : item))} /><i style={{ background: calendar.color ?? "#557f95" }} /><span>{calendar.summary}</span></label>)}<button className="primary-button" disabled={saving} onClick={() => void saveCalendars()}>{saving ? "Saving…" : "Save calendar selection"}</button></div></> : <div className="integration-status"><span className="google-g">G</span><span><strong>Connect Google</strong><small>{status.configured ? "Choose your calendars and search Gmail from tasks." : "Google credentials still need to be added by the site administrator."}</small></span>{status.configured && <a className="primary-button" href="/api/google/connect">Connect</a>}</div>}<div className="reminder-settings"><span className="summary-icon violet"><Icon name="sun" /></span><span><strong>Browser reminders</strong><small>Receive task alerts while the notebook is open.</small></span><button className="secondary-button" onClick={async () => { if ("Notification" in window) { const result = await Notification.requestPermission(); setError(result === "granted" ? "Reminders enabled" : "Notifications were not enabled"); } }}>Enable</button></div>{error && <p className="form-error">{error}</p>}</div></Modal>;
}

function CategoryManager({ categories, close, changed }: { categories: Category[]; close: () => void; changed: () => Promise<void> }) {
  const [name, setName] = useState(""); const [color, setColor] = useState(colours[0]); const [editing, setEditing] = useState<Category | null>(null); const [deleting, setDeleting] = useState<Category | null>(null); const [replacementId, setReplacementId] = useState(""); const [error, setError] = useState(""); const [busy, setBusy] = useState(false);
  function resetEditor() { setName(""); setColor(colours[0]); setEditing(null); }
  async function submit(event: FormEvent) { event.preventDefault(); setBusy(true); setError(""); try { await api("/api/categories", { method: editing ? "PATCH" : "POST", body: JSON.stringify({ id: editing?.id, name, color }) }); resetEditor(); await changed(); } catch (reason) { setError(reason instanceof Error ? reason.message : "Unable to save category"); } finally { setBusy(false); } }
  async function removeCategory(mode: "reassign" | "unassign") {
    if (!deleting) return;
    if (mode === "reassign" && !replacementId) return setError("Choose a replacement category");
    setBusy(true); setError("");
    const query = mode === "reassign" ? `replacementId=${encodeURIComponent(replacementId)}` : "unassign=true";
    try { await api(`/api/categories?id=${encodeURIComponent(deleting.id)}&${query}`, { method: "DELETE" }); setDeleting(null); setReplacementId(""); await changed(); }
    catch (reason) { setError(reason instanceof Error ? reason.message : "Unable to delete category"); }
    finally { setBusy(false); }
  }
  async function requestDelete(category: Category) {
    setError(""); resetEditor();
    if (category.taskCount > 0) { setDeleting(category); setReplacementId(""); return; }
    if (!confirm(`Delete ${category.name}?`)) return;
    setBusy(true);
    try { await api(`/api/categories?id=${encodeURIComponent(category.id)}`, { method: "DELETE" }); await changed(); }
    catch (reason) { setError(reason instanceof Error ? reason.message : "Unable to delete category"); }
    finally { setBusy(false); }
  }
  return <Modal title="Manage categories" subtitle="Add, rename, recolour, or safely remove categories." close={close}><form className="manager-form" onSubmit={submit}><div className="category-editor"><input value={name} onChange={event => setName(event.target.value)} placeholder="Category name" required /><div className="colour-options">{colours.map(item => <button type="button" key={item} className={color === item ? "active" : ""} style={{ background: item }} onClick={() => setColor(item)} aria-label={`Use ${item}`} />)}</div><button className="primary-button" disabled={busy}>{editing ? "Save changes" : "Add category"}</button>{editing && <button type="button" className="text-button" onClick={resetEditor}>Cancel</button>}</div>{error && <p className="form-error">{error}</p>}<div className="manager-list category-manager-list">{categories.map(category => <div key={category.id}><i style={{ background: category.color ?? "#6556a5" }} /><span><strong>{category.name}</strong><small>{category.taskCount} {category.taskCount === 1 ? "task" : "tasks"}</small></span><button type="button" onClick={() => { setDeleting(null); setEditing(category); setName(category.name); setColor(category.color ?? colours[0]); }} aria-label={`Edit ${category.name}`} title="Edit category"><Icon name="edit" /></button><button type="button" onClick={() => void requestDelete(category)} aria-label={`Delete ${category.name}`} title="Delete category"><Icon name="trash" /></button></div>)}</div></form>{deleting && <div className="category-delete-panel"><div><p className="eyebrow">Safe deletion</p><h3>Move {deleting.taskCount} {deleting.taskCount === 1 ? "task" : "tasks"} from “{deleting.name}”</h3><p>Choose another category, or explicitly leave these tasks uncategorised.</p></div><label>Replacement category<select value={replacementId} onChange={event => setReplacementId(event.target.value)}><option value="">Choose a category…</option>{categories.filter(category => category.id !== deleting.id).map(category => <option value={category.id} key={category.id}>{category.name}</option>)}</select></label><div className="category-delete-actions"><button type="button" className="secondary-button" onClick={() => { setDeleting(null); setReplacementId(""); }}>Cancel</button><button type="button" className="secondary-button" disabled={busy} onClick={() => void removeCategory("unassign")}>Leave uncategorised</button><button type="button" className="danger-button" disabled={busy || !replacementId} onClick={() => void removeCategory("reassign")}>Reassign &amp; delete</button></div></div>}</Modal>;
}

function AccessManager({ currentEmail, categories, close }: { currentEmail: string; categories: Category[]; close: () => void }) {
  const [users, setUsers] = useState<AllowedUser[]>([]); const [email, setEmail] = useState(""); const [role, setRole] = useState<"ADMIN" | "MEMBER">("MEMBER"); const [error, setError] = useState("");
  const load = useCallback(async () => { try { const data = await api<{ users: AllowedUser[] }>("/api/access"); setUsers(data.users); } catch (reason) { setError(reason instanceof Error ? reason.message : "Unable to load access list"); } }, []);
  useEffect(() => { const timer = window.setTimeout(() => void load(), 0); return () => window.clearTimeout(timer); }, [load]);
  async function add(event: FormEvent) { event.preventDefault(); try { await api("/api/access", { method: "POST", body: JSON.stringify({ email, role }) }); setEmail(""); await load(); } catch (reason) { setError(reason instanceof Error ? reason.message : "Unable to update access"); } }
  async function setPermission(user: AllowedUser, categoryId: string, permission: CategoryPermission | null) { setError(""); try { await api("/api/access", { method: "PATCH", body: JSON.stringify({ email: user.email, categoryId, permission }) }); await load(); } catch (reason) { setError(reason instanceof Error ? reason.message : "Unable to update category access"); } }
  return <Modal title="People & category access" subtitle="Approve people, then choose exactly which categories they can use." close={close}><form className="manager-form" onSubmit={add}><div className="access-add"><input type="email" value={email} onChange={event => setEmail(event.target.value)} placeholder="name@example.com" required /><select value={role} onChange={event => setRole(event.target.value as "ADMIN" | "MEMBER")}><option value="MEMBER">Member — selected categories</option><option value="ADMIN">Administrator — everything</option></select><button className="primary-button">Approve user</button></div>{error && <p className="form-error">{error}</p>}<div className="access-note"><Icon name="lock" /><span>Viewers can read. Contributors can also create and edit. Managers can additionally archive and permanently delete.</span></div><div className="access-user-list">{users.filter(user => user.isActive).map(user => <article className="access-user-card" key={user.id}><div className="access-user-head"><span className="user-letter">{user.email[0].toUpperCase()}</span><span><strong>{user.email}</strong><small>{user.role === "ADMIN" ? "Administrator · Full access" : "Member · Category-limited"}{user.email === currentEmail ? " · You" : ""}</small></span><button type="button" disabled={user.email === currentEmail} onClick={async () => { if (confirm(`Remove access for ${user.email}?`)) { try { await api(`/api/access?email=${encodeURIComponent(user.email)}`, { method: "DELETE" }); await load(); } catch (reason) { setError(reason instanceof Error ? reason.message : "Unable to remove user"); } } }} aria-label={`Remove ${user.email}`}><Icon name="trash" /></button></div>{user.role === "MEMBER" && <div className="category-permission-list">{categories.map(category => { const permission = user.categoryPermissions.find(item => item.categoryId === category.id)?.permission ?? ""; return <label key={category.id}><span><i style={{ background: category.color ?? "#6556a5" }} />{category.name}</span><select value={permission} onChange={event => void setPermission(user, category.id, (event.target.value || null) as CategoryPermission | null)} aria-label={`${category.name} access for ${user.email}`}><option value="">No access</option><option value="VIEWER">View only</option><option value="CONTRIBUTOR">Contributor</option><option value="MANAGER">Manager</option></select></label>; })}{categories.length === 0 && <p className="panel-empty">Add categories before assigning access.</p>}</div>}</article>)}</div></form></Modal>;
}

function SearchModal({ query, setQuery, tasks, categories, close, open }: { query: string; setQuery: (value: string) => void; tasks: Task[]; categories: Map<string, Category>; close: () => void; open: (task: Task) => void }) {
  return <div className="modal-layer"><button className="modal-scrim" onClick={close} /><section className="command-modal"><div className="command-input"><Icon name="search" /><input autoFocus value={query} onChange={event => setQuery(event.target.value)} placeholder="Search tasks and notes…" /><kbd>ESC</kbd></div><div className="command-results"><span className="result-label">{tasks.length} results</span>{tasks.slice(0, 8).map(task => <button key={task.id} onClick={() => open(task)}><span className={`result-icon ${task.status === "DONE" ? "green" : "violet"}`}><Icon name="check" /></span><span><strong>{task.title}</strong><small>{formatDue(task.dueDate)} · {categories.get(task.categoryId ?? "")?.name ?? "Uncategorised"}{task.parentId ? " · Child task" : ""}</small></span><Icon name="chevron" /></button>)}</div></section></div>;
}

function Modal({ title, subtitle, close, children }: { title: string; subtitle: string; close: () => void; children: React.ReactNode }) { return <div className="modal-layer"><button className="modal-scrim" onClick={close} /><section className="manager-modal"><div className="manager-head"><div><p className="eyebrow">Settings</p><h2>{title}</h2><span>{subtitle}</span></div><button className="icon-button" onClick={close}><Icon name="close" /></button></div>{children}</section></div>; }
function Loading() { return <div className="loading-list">{[1,2,3,4].map(item => <span key={item} />)}</div>; }
function Empty({ archived, add }: { archived: boolean; add: () => void }) { return <div className="empty-state"><span className="empty-icon"><Icon name={archived ? "archive" : "list"} /></span><h3>{archived ? "Nothing archived" : "Your list is clear"}</h3><p>{archived ? "Archived tasks will appear here." : "Add a task, then create child tasks for the next steps."}</p>{!archived && <button className="primary-button" onClick={add}>Add your first task</button>}</div>; }
