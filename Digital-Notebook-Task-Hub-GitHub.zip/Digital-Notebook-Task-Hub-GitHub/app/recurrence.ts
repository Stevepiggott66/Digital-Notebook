import { and, asc, eq, isNotNull, isNull, ne } from "drizzle-orm";
import { getDb } from "../db";
import { recurringSeries, tasks } from "../db/schema";

export type Recurrence = "NONE" | "DAILY" | "WEEKLY" | "MONTHLY";
export type SeriesRecurrence = Exclude<Recurrence, "NONE">;

const MATERIALIZE_DAYS: Record<SeriesRecurrence, number> = {
  DAILY: 35,
  WEEKLY: 182,
  MONTHLY: 400,
};
const MAX_OCCURRENCES_PER_PASS = 100;

export function nextMoment(value: Date, recurrence: SeriesRecurrence) {
  const next = new Date(value);
  if (recurrence === "DAILY") next.setUTCDate(next.getUTCDate() + 1);
  if (recurrence === "WEEKLY") next.setUTCDate(next.getUTCDate() + 7);
  if (recurrence === "MONTHLY") {
    const day = next.getUTCDate();
    next.setUTCDate(1);
    next.setUTCMonth(next.getUTCMonth() + 1);
    const lastDay = new Date(Date.UTC(next.getUTCFullYear(), next.getUTCMonth() + 1, 0)).getUTCDate();
    next.setUTCDate(Math.min(day, lastDay));
  }
  return next;
}

export function minutesBetween(value: Date | null, due: Date | null) {
  return value && due ? Math.round((value.getTime() - due.getTime()) / 60_000) : null;
}

export function dateWithOffset(due: Date, minutes: number | null) {
  return minutes === null ? null : new Date(due.getTime() + minutes * 60_000);
}

async function migrateLegacyRecurringTasks() {
  const db = getDb();
  const legacy = await db.select().from(tasks).where(and(ne(tasks.recurrence, "NONE"), isNull(tasks.seriesId), isNotNull(tasks.dueDate)));
  for (const task of legacy) {
    if (!task.dueDate || task.recurrence === "NONE") continue;
    const seriesId = crypto.randomUUID();
    const now = new Date();
    await db.insert(recurringSeries).values({
      id: seriesId,
      title: task.title,
      priority: task.priority,
      recurrence: task.recurrence,
      nextOccurrenceAt: nextMoment(task.dueDate, task.recurrence),
      plannedOffsetMinutes: minutesBetween(task.plannedDate, task.dueDate),
      reminderOffsetMinutes: minutesBetween(task.reminderAt, task.dueDate),
      categoryId: task.categoryId,
      parentId: task.parentId,
      userId: task.userId,
      pausedAt: null,
      deletedAt: null,
      createdAt: now,
      updatedAt: now,
    });
    const claimed = await db.update(tasks).set({ seriesId, occurrenceDate: task.dueDate, recurrenceGeneratedAt: null, updatedAt: now }).where(and(eq(tasks.id, task.id), isNull(tasks.seriesId))).returning({ id: tasks.id });
    if (!claimed[0]) await db.delete(recurringSeries).where(eq(recurringSeries.id, seriesId));
  }
}

export async function ensureRecurringTasks() {
  await migrateLegacyRecurringTasks();
  const db = getDb();
  const seriesRows = await db.select().from(recurringSeries).where(and(isNull(recurringSeries.pausedAt), isNull(recurringSeries.deletedAt)));

  for (const series of seriesRows) {
    const horizon = new Date(Date.now() + MATERIALIZE_DAYS[series.recurrence] * 24 * 60 * 60 * 1000);
    const existing = await db.select({ id: tasks.id, occurrenceDate: tasks.occurrenceDate }).from(tasks).where(eq(tasks.seriesId, series.id)).orderBy(asc(tasks.occurrenceDate));
    const byDate = new Map(existing.filter(item => item.occurrenceDate).map(item => [item.occurrenceDate!.getTime(), item.id]));
    let previousId = existing.filter(item => item.occurrenceDate && item.occurrenceDate < series.nextOccurrenceAt).at(-1)?.id ?? null;
    let occurrence = series.nextOccurrenceAt;
    let generated = 0;

    while (occurrence <= horizon && generated < MAX_OCCURRENCES_PER_PASS) {
      const existingId = byDate.get(occurrence.getTime());
      if (existingId) previousId = existingId;
      else {
        const id = crypto.randomUUID();
        const now = new Date();
        await db.insert(tasks).values({
          id,
          title: series.title,
          description: null,
          priority: series.priority,
          status: "TODO",
          startDate: now,
          dueDate: occurrence,
          plannedDate: dateWithOffset(occurrence, series.plannedOffsetMinutes),
          reminderAt: dateWithOffset(occurrence, series.reminderOffsetMinutes),
          recurrence: series.recurrence,
          recurrenceGeneratedAt: null,
          seriesId: series.id,
          previousOccurrenceId: previousId,
          occurrenceDate: occurrence,
          isArchived: false,
          userId: series.userId,
          categoryId: series.categoryId,
          parentId: series.parentId,
          createdAt: now,
          updatedAt: now,
        }).onConflictDoNothing({ target: [tasks.seriesId, tasks.occurrenceDate] });
        const inserted = (await db.select({ id: tasks.id }).from(tasks).where(and(eq(tasks.seriesId, series.id), eq(tasks.occurrenceDate, occurrence))).limit(1))[0];
        previousId = inserted?.id ?? previousId;
      }
      occurrence = nextMoment(occurrence, series.recurrence);
      generated += 1;
    }

    if (occurrence.getTime() !== series.nextOccurrenceAt.getTime()) {
      await db.update(recurringSeries).set({ nextOccurrenceAt: occurrence, updatedAt: new Date() }).where(eq(recurringSeries.id, series.id));
    }
  }
}
