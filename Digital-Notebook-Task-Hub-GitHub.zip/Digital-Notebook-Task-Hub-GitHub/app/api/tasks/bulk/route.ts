import { inArray } from "drizzle-orm";
import { requireAccess } from "../../../access";
import { canUseCategory, canUseTask } from "../../../category-access";
import { getDb } from "../../../../db";
import { tasks } from "../../../../db/schema";

type Status = "TODO" | "IN_PROGRESS" | "WAITING" | "DONE";

export async function PATCH(request: Request) {
  const access = await requireAccess();
  if (access.error || !access.user) return access.error;
  const input = await request.json() as { ids?: string[]; status?: Status; categoryId?: string | null; isArchived?: boolean };
  const ids = [...new Set(input.ids ?? [])].slice(0, 250);
  if (!ids.length) return Response.json({ error: "Choose at least one task" }, { status: 400 });
  const requiredPermission = input.isArchived !== undefined ? "MANAGER" : "CONTRIBUTOR";
  for (const id of ids) if (!await canUseTask(access.user, id, requiredPermission)) return Response.json({ error: `You need ${requiredPermission === "MANAGER" ? "manager" : "edit"} access for every selected task` }, { status: 403 });
  if (input.categoryId !== undefined && !await canUseCategory(access.user, input.categoryId || null, "CONTRIBUTOR")) return Response.json({ error: "You cannot move tasks to that category" }, { status: 403 });
  const patch = {
    ...(input.status !== undefined && { status: input.status }),
    ...(input.categoryId !== undefined && { categoryId: input.categoryId || null }),
    ...(input.isArchived !== undefined && { isArchived: input.isArchived }),
    updatedAt: new Date(),
  };
  const targetIds = new Set(ids);
  if (input.isArchived !== undefined) {
    const ownedTasks = await getDb().select({ id: tasks.id, parentId: tasks.parentId }).from(tasks);
    let foundDescendant = true;
    while (foundDescendant) {
      foundDescendant = false;
      for (const task of ownedTasks) if (task.parentId && targetIds.has(task.parentId) && !targetIds.has(task.id)) { targetIds.add(task.id); foundDescendant = true; }
    }
    for (const id of targetIds) if (!await canUseTask(access.user, id, "MANAGER")) return Response.json({ error: "Manager access is required for every child task in the selected branches" }, { status: 403 });
  }
  const updated = await getDb().update(tasks).set(patch).where(inArray(tasks.id, [...targetIds])).returning({ id: tasks.id });
  return Response.json({ updated: updated.length });
}
