import { and, asc, count, eq } from "drizzle-orm";
import { requireAdmin } from "../../access";
import { getDb } from "../../../db";
import { allowedUsers, categoryPermissions } from "../../../db/schema";

export async function GET() {
  const access = await requireAdmin();
  if (access.error) return access.error;
  const db = getDb();
  const [users, permissions] = await Promise.all([
    db.select().from(allowedUsers).orderBy(asc(allowedUsers.createdAt)),
    db.select().from(categoryPermissions),
  ]);
  return Response.json({ users: users.map(user => ({ ...user, categoryPermissions: permissions.filter(item => item.allowedUserId === user.id).map(item => ({ categoryId: item.categoryId, permission: item.permission })) })) });
}

export async function POST(request: Request) {
  const access = await requireAdmin();
  if (access.error || !access.user) return access.error;
  const input = await request.json() as { email?: string; role?: "ADMIN" | "MEMBER" };
  const email = input.email?.trim().toLowerCase();
  if (!email || !/^\S+@\S+\.\S+$/.test(email)) return Response.json({ error: "Enter a valid email address" }, { status: 400 });
  const existing = await getDb().select().from(allowedUsers).where(eq(allowedUsers.email, email)).limit(1);
  if (existing[0]?.role === "ADMIN" && input.role === "MEMBER") {
    const admins = await getDb().select({ value: count() }).from(allowedUsers).where(and(eq(allowedUsers.role, "ADMIN"), eq(allowedUsers.isActive, true)));
    if ((admins[0]?.value ?? 0) <= 1) return Response.json({ error: "Add another administrator before changing your own role" }, { status: 409 });
  }
  await getDb().insert(allowedUsers).values({ id: crypto.randomUUID(), email, role: input.role === "ADMIN" ? "ADMIN" : "MEMBER", isActive: true, createdBy: access.user.email, createdAt: new Date() }).onConflictDoUpdate({ target: allowedUsers.email, set: { role: input.role === "ADMIN" ? "ADMIN" : "MEMBER", isActive: true } });
  return Response.json({ ok: true });
}

export async function DELETE(request: Request) {
  const access = await requireAdmin();
  if (access.error || !access.user) return access.error;
  const email = new URL(request.url).searchParams.get("email")?.toLowerCase();
  if (!email) return Response.json({ error: "Email is required" }, { status: 400 });
  const target = await getDb().select().from(allowedUsers).where(eq(allowedUsers.email, email)).limit(1);
  if (!target[0]) return Response.json({ error: "User not found" }, { status: 404 });
  if (target[0].role === "ADMIN") {
    const admins = await getDb().select({ value: count() }).from(allowedUsers).where(and(eq(allowedUsers.role, "ADMIN"), eq(allowedUsers.isActive, true)));
    if ((admins[0]?.value ?? 0) <= 1) return Response.json({ error: "The final administrator cannot be removed" }, { status: 409 });
  }
  await getDb().update(allowedUsers).set({ isActive: false }).where(eq(allowedUsers.email, email));
  return Response.json({ ok: true });
}

export async function PATCH(request: Request) {
  const access = await requireAdmin();
  if (access.error) return access.error;
  const input = await request.json() as { email?: string; categoryId?: string; permission?: "VIEWER" | "CONTRIBUTOR" | "MANAGER" | null };
  const email = input.email?.trim().toLowerCase();
  if (!email || !input.categoryId) return Response.json({ error: "User and category are required" }, { status: 400 });
  const user = (await getDb().select().from(allowedUsers).where(and(eq(allowedUsers.email, email), eq(allowedUsers.isActive, true))).limit(1))[0];
  if (!user) return Response.json({ error: "Approved user not found" }, { status: 404 });
  if (user.role === "ADMIN") return Response.json({ error: "Administrators already have access to every category" }, { status: 409 });
  if (!input.permission) {
    await getDb().delete(categoryPermissions).where(and(eq(categoryPermissions.allowedUserId, user.id), eq(categoryPermissions.categoryId, input.categoryId)));
  } else {
    const now = new Date();
    await getDb().insert(categoryPermissions).values({ categoryId: input.categoryId, allowedUserId: user.id, permission: input.permission, createdAt: now, updatedAt: now }).onConflictDoUpdate({ target: [categoryPermissions.categoryId, categoryPermissions.allowedUserId], set: { permission: input.permission, updatedAt: now } });
  }
  return Response.json({ ok: true });
}
