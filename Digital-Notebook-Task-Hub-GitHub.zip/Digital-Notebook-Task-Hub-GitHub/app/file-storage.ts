import { env } from "cloudflare:workers";

export function getFileBucket() {
  const bucket = (env as unknown as { FILES?: R2Bucket }).FILES;
  if (!bucket) throw new Error("File storage is unavailable");
  return bucket;
}
