import { desc, eq } from "drizzle-orm";
import { requireAccess } from "../../access";
import type { AccessUser } from "../../access";
import { canUseTask, type CategoryPermission } from "../../category-access";
import { getFileBucket } from "../../file-storage";
import { getDb } from "../../../db";
import { taskAttachments } from "../../../db/schema";

const MAX_FILE_SIZE = 20 * 1024 * 1024;
const BLOCKED_EXTENSIONS = new Set(["app", "bat", "cmd", "com", "dmg", "exe", "html", "htm", "js", "jar", "msi", "ps1", "sh", "svg"]);
const BLOCKED_TYPES = new Set(["image/svg+xml", "text/html", "application/javascript", "text/javascript", "application/x-msdownload", "application/x-sh"]);

async function accessibleAttachment(id: string, user: AccessUser, required: CategoryPermission) {
  const attachment = (await getDb().select({
    id: taskAttachments.id,
    taskId: taskAttachments.taskId,
    storageKey: taskAttachments.storageKey,
    fileName: taskAttachments.fileName,
    contentType: taskAttachments.contentType,
    size: taskAttachments.size,
    createdAt: taskAttachments.createdAt,
  }).from(taskAttachments).where(eq(taskAttachments.id, id)).limit(1))[0];
  return attachment && await canUseTask(user, attachment.taskId, required) ? attachment : null;
}

function safeFileName(value: string) {
  return value.replace(/[\r\n"\\/]/g, "_").replace(/[^\x20-\x7E]/g, "_").slice(0, 180) || "attachment";
}

function isBlocked(file: File) {
  const extension = file.name.split(".").pop()?.toLowerCase() ?? "";
  return BLOCKED_EXTENSIONS.has(extension) || BLOCKED_TYPES.has(file.type.toLowerCase());
}

export async function GET(request: Request) {
  const access = await requireAccess();
  if (access.error || !access.user) return access.error;
  const search = new URL(request.url).searchParams;
  const taskId = search.get("taskId");
  const id = search.get("id");

  if (taskId) {
    if (!await canUseTask(access.user, taskId, "VIEWER")) return Response.json({ error: "Task not found" }, { status: 404 });
    const attachments = await getDb().select({ id: taskAttachments.id, taskId: taskAttachments.taskId, fileName: taskAttachments.fileName, contentType: taskAttachments.contentType, size: taskAttachments.size, createdAt: taskAttachments.createdAt }).from(taskAttachments).where(eq(taskAttachments.taskId, taskId)).orderBy(desc(taskAttachments.createdAt));
    return Response.json({ attachments });
  }

  if (!id) return Response.json({ error: "Attachment id is required" }, { status: 400 });
  const attachment = await accessibleAttachment(id, access.user, "VIEWER");
  if (!attachment) return Response.json({ error: "Attachment not found" }, { status: 404 });
  const object = await getFileBucket().get(attachment.storageKey);
  if (!object) return Response.json({ error: "Stored file not found" }, { status: 404 });
  const inline = attachment.contentType === "application/pdf" || /^image\/(jpeg|png|gif|webp)$/.test(attachment.contentType);
  const asciiName = safeFileName(attachment.fileName);
  return new Response(object.body, { headers: {
    "Content-Type": attachment.contentType || "application/octet-stream",
    "Content-Length": String(attachment.size),
    "Content-Disposition": `${inline ? "inline" : "attachment"}; filename="${asciiName}"; filename*=UTF-8''${encodeURIComponent(attachment.fileName)}`,
    "Cache-Control": "private, max-age=3600",
    "X-Content-Type-Options": "nosniff",
    "Content-Security-Policy": "sandbox",
  } });
}

export async function POST(request: Request) {
  const access = await requireAccess();
  if (access.error || !access.user) return access.error;
  const form = await request.formData();
  const taskId = form.get("taskId");
  const file = form.get("file");
  if (typeof taskId !== "string" || !await canUseTask(access.user, taskId, "CONTRIBUTOR")) return Response.json({ error: "You cannot attach files to this task" }, { status: 403 });
  if (!(file instanceof File) || !file.name) return Response.json({ error: "Choose a file to attach" }, { status: 400 });
  if (file.size === 0) return Response.json({ error: "The selected file is empty" }, { status: 400 });
  if (file.size > MAX_FILE_SIZE) return Response.json({ error: "Files must be 20 MB or smaller" }, { status: 413 });
  if (isBlocked(file)) return Response.json({ error: "This file type cannot be attached" }, { status: 415 });

  const id = crypto.randomUUID();
  const storageKey = `${access.user.id}/${taskId}/${id}`;
  const contentType = file.type || "application/octet-stream";
  await getFileBucket().put(storageKey, file.stream(), { httpMetadata: { contentType }, customMetadata: { fileName: file.name } });
  const attachment = { id, taskId, storageKey, fileName: file.name.slice(0, 255), contentType, size: file.size, createdAt: new Date() };
  try { await getDb().insert(taskAttachments).values(attachment); }
  catch (error) { await getFileBucket().delete(storageKey); throw error; }
  return Response.json({ attachment: { id, taskId, fileName: attachment.fileName, contentType, size: file.size, createdAt: attachment.createdAt } }, { status: 201 });
}

export async function DELETE(request: Request) {
  const access = await requireAccess();
  if (access.error || !access.user) return access.error;
  const id = new URL(request.url).searchParams.get("id");
  if (!id) return Response.json({ error: "Attachment id is required" }, { status: 400 });
  const attachment = await accessibleAttachment(id, access.user, "CONTRIBUTOR");
  if (!attachment) return Response.json({ error: "Attachment not found" }, { status: 404 });
  await getFileBucket().delete(attachment.storageKey);
  await getDb().delete(taskAttachments).where(eq(taskAttachments.id, id));
  return Response.json({ ok: true });
}
