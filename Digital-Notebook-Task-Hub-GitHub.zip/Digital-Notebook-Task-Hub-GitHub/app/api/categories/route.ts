import { asc, count, eq, inArray } from "drizzle-orm";
import { requireAccess, requireAdmin } from "../../access";
import { categoryAccessMap } from "../../category-access";
import { getDb } from "../../../db";
import { categories, tasks } from "../../../db/schema";

async function duplicateName(name: string, excludeId?: string) {
  const rows = await getDb().select({ id: categories.id, name: categories.name }).from(categories);
  return rows.some(category => category.id !== excludeId && category.name.localeCompare(name, undefined, { sensitivity: "accent" }) === 0);
}

export async function GET() {
  const access = await requireAccess();
  if (access.error || !access.user) return access.error;
  const permissions = await categoryAccessMap(access.user);
  const ids = [...permissions.keys()];
  if (!ids.length) return Response.json({ categories: [] });
  const rows = await getDb().select({ id: categories.id, name: categories.name, color: categories.color, userId: categories.userId, createdAt: categories.createdAt, taskCount: count(tasks.id) }).from(categories).leftJoin(tasks, eq(tasks.categoryId, categories.id)).where(inArray(categories.id, ids)).groupBy(categories.id).orderBy(asc(categories.name));
  return Response.json({ categories: rows.map(category => ({ ...category, permission: permissions.get(category.id) })) });
}

export async function POST(request: Request) {
  const access = await requireAdmin();
  if (access.error || !access.user) return access.error;
  const input = await request.json() as { name?: string; color?: string };
  const name = input.name?.trim();
  if (!name) return Response.json({ error: "Category name is required" }, { status: 400 });
  if (await duplicateName(name)) return Response.json({ error: "A category with this name already exists" }, { status: 409 });
  const category = { id: crypto.randomUUID(), name, color: input.color ?? "#6556a5", userId: access.user.id, createdAt: new Date() };
  await getDb().insert(categories).values(category);
  return Response.json({ category: { ...category, taskCount: 0, permission: "MANAGER" } }, { status: 201 });
}

export async function PATCH(request: Request) {
  const access = await requireAdmin();
  if (access.error || !access.user) return access.error;
  const input = await request.json() as { id?: string; name?: string; color?: string };
  const name = input.name?.trim();
  if (!input.id || !name) return Response.json({ error: "Category id and name are required" }, { status: 400 });
  if (await duplicateName(name, input.id)) return Response.json({ error: "A category with this name already exists" }, { status: 409 });
  const updated = await getDb().update(categories).set({ name, color: input.color ?? "#6556a5" }).where(eq(categories.id, input.id)).returning();
  if (!updated[0]) return Response.json({ error: "Category not found" }, { status: 404 });
  return Response.json({ category: { ...updated[0], permission: "MANAGER" } });
}

export async function DELETE(request: Request) {
  const access = await requireAdmin();
  if (access.error || !access.user) return access.error;
  const search = new URL(request.url).searchParams;
  const id = search.get("id");
  const replacementId = search.get("replacementId");
  const unassign = search.get("unassign") === "true";
  if (!id) return Response.json({ error: "Category id is required" }, { status: 400 });
  const db = getDb();
  const category = await db.select({ id: categories.id }).from(categories).where(eq(categories.id, id)).limit(1);
  if (!category[0]) return Response.json({ error: "Category not found" }, { status: 404 });
  const affected = await db.select({ value: count() }).from(tasks).where(eq(tasks.categoryId, id));
  const affectedTasks = affected[0]?.value ?? 0;
  if (affectedTasks > 0 && !replacementId && !unassign) return Response.json({ error: "Choose where assigned tasks should go before deleting this category", affectedTasks }, { status: 409 });
  if (replacementId === id) return Response.json({ error: "Choose a different replacement category" }, { status: 400 });
  if (replacementId) {
    const replacement = await db.select({ id: categories.id }).from(categories).where(eq(categories.id, replacementId)).limit(1);
    if (!replacement[0]) return Response.json({ error: "Replacement category not found" }, { status: 404 });
  }
  const taskUpdate = affectedTasks > 0 ? db.update(tasks).set({ categoryId: replacementId || null, updatedAt: new Date() }).where(eq(tasks.categoryId, id)) : null;
  const categoryDelete = db.delete(categories).where(eq(categories.id, id));
  if (taskUpdate) await db.batch([taskUpdate, categoryDelete]); else await categoryDelete;
  return Response.json({ ok: true, reassignedTasks: affectedTasks, replacementId: replacementId || null });
}
