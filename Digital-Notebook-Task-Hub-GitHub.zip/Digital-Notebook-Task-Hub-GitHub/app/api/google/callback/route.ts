import { eq } from "drizzle-orm";
import { requireAccess } from "../../../access";
import { googleConfig } from "../../../google";
import { getDb } from "../../../../db";
import { users } from "../../../../db/schema";

type TokenResponse = { access_token?: string; refresh_token?: string; expires_in?: number; scope?: string; error_description?: string };

export async function GET(request: Request) {
  const access = await requireAccess(); if (access.error || !access.user) return access.error;
  const url = new URL(request.url); const code = url.searchParams.get("code"); const state = url.searchParams.get("state");
  const savedState = request.headers.get("cookie")?.match(/(?:^|;\s*)google_oauth_state=([^;]+)/)?.[1];
  if (!code || !state || state !== savedState) return Response.json({ error: "Google connection could not be verified" }, { status: 400 });
  const config = googleConfig(request); if (!config.configured) return Response.json({ error: "Google integration is not configured" }, { status: 503 });
  const response = await fetch("https://oauth2.googleapis.com/token", { method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body: new URLSearchParams({ client_id: config.clientId, client_secret: config.clientSecret, code, redirect_uri: config.redirectUri, grant_type: "authorization_code" }) });
  const token = await response.json() as TokenResponse;
  if (!response.ok || !token.access_token) return Response.json({ error: token.error_description || "Google did not complete the connection" }, { status: 400 });
  const current = (await getDb().select().from(users).where(eq(users.id, access.user.id)).limit(1))[0];
  await getDb().update(users).set({ googleAccessToken: token.access_token, googleRefreshToken: token.refresh_token ?? current?.googleRefreshToken ?? null, googleTokenExpiresAt: new Date(Date.now() + (token.expires_in ?? 3600) * 1000), googleScopes: token.scope ?? null, updatedAt: new Date() }).where(eq(users.id, access.user.id));
  return new Response(null, { status: 302, headers: { Location: "/?google=connected", "Set-Cookie": "google_oauth_state=; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=0" } });
}
