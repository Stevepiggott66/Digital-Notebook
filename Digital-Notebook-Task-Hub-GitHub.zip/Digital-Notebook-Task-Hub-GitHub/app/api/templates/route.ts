import { and, asc, eq } from "drizzle-orm";
import { requireAccess } from "../../access";
import { canUseCategory } from "../../category-access";
import { getDb } from "../../../db";
import { taskTemplates } from "../../../db/schema";

export async function GET() {
  const access = await requireAccess(); if (access.error || !access.user) return access.error;
  const templates = await getDb().select().from(taskTemplates).where(eq(taskTemplates.userId, access.user.id)).orderBy(asc(taskTemplates.name));
  return Response.json({ templates: templates.map(item => ({ ...item, childTitles: JSON.parse(item.childTitles || "[]") })) });
}

export async function POST(request: Request) {
  const access = await requireAccess(); if (access.error || !access.user) return access.error;
  const input = await request.json() as { name?: string; title?: string; description?: string | null; priority?: "LOW" | "MEDIUM" | "HIGH"; status?: "TODO" | "IN_PROGRESS" | "WAITING" | "DONE"; categoryId?: string | null; recurrence?: "NONE" | "DAILY" | "WEEKLY" | "MONTHLY"; childTitles?: string[] };
  if (!input.name?.trim() || !input.title?.trim()) return Response.json({ error: "Template name and task title are required" }, { status: 400 });
  if (!await canUseCategory(access.user, input.categoryId || null, "CONTRIBUTOR")) return Response.json({ error: "Choose a category where you have create access" }, { status: 403 });
  const template = { id: crypto.randomUUID(), name: input.name.trim(), title: input.title.trim(), description: input.description || null, priority: input.priority ?? "MEDIUM" as const, status: input.status ?? "TODO" as const, categoryId: input.categoryId || null, recurrence: input.recurrence ?? "NONE" as const, childTitles: JSON.stringify((input.childTitles ?? []).map(item => item.trim()).filter(Boolean)), userId: access.user.id, createdAt: new Date() };
  await getDb().insert(taskTemplates).values(template); return Response.json({ template: { ...template, childTitles: JSON.parse(template.childTitles) } }, { status: 201 });
}

export async function DELETE(request: Request) {
  const access = await requireAccess(); if (access.error || !access.user) return access.error;
  const id = new URL(request.url).searchParams.get("id"); if (!id) return Response.json({ error: "Template id is required" }, { status: 400 });
  await getDb().delete(taskTemplates).where(and(eq(taskTemplates.id, id), eq(taskTemplates.userId, access.user.id)));
  return Response.json({ ok: true });
}
