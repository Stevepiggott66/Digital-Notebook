import { requireAccess } from "../../../access";
import { googleFetch } from "../../../google";

type GmailPart = { mimeType?: string; body?: { data?: string }; parts?: GmailPart[] };
type GmailMessage = { id: string; snippet?: string; internalDate?: string; payload?: GmailPart & { headers?: { name: string; value: string }[] } };

function messageIdFrom(value: string) {
  if (/^[a-zA-Z0-9_-]{8,}$/.test(value)) return value;
  try {
    const url = new URL(value);
    if (url.hostname !== "mail.google.com") return null;
    return url.hash.match(/\/(?:inbox|all|sent|search|label\/[^/]+)\/([a-zA-Z0-9_-]+)/)?.[1] ?? url.hash.match(/#(?:inbox|all|sent)\/([a-zA-Z0-9_-]+)/)?.[1] ?? null;
  } catch { return null; }
}

function decodeUrlBase64(value = "") {
  const normalized = value.replace(/-/g, "+").replace(/_/g, "/");
  const bytes = Uint8Array.from(atob(normalized), character => character.charCodeAt(0));
  return new TextDecoder().decode(bytes);
}

function findBody(part?: GmailPart): string {
  if (!part) return "";
  if (part.mimeType === "text/html" && part.body?.data) return decodeUrlBase64(part.body.data);
  for (const child of part.parts ?? []) { const body = findBody(child); if (body) return body; }
  if (part.mimeType === "text/plain" && part.body?.data) return `<p>${decodeUrlBase64(part.body.data).replace(/[<>&]/g, character => ({ "<": "&lt;", ">": "&gt;", "&": "&amp;" }[character] ?? character)).replace(/\n/g, "<br>")}</p>`;
  return "";
}

export async function POST(request: Request) {
  const access = await requireAccess();
  if (access.error || !access.user) return access.error;
  const { url } = await request.json() as { url?: string };
  const id = url ? messageIdFrom(url) : null;
  if (!id) return Response.json({ error: "Paste a valid Gmail message link" }, { status: 400 });
  let response: Response;
  try { response = await googleFetch(access.user.id, request, `https://gmail.googleapis.com/gmail/v1/users/me/messages/${encodeURIComponent(id)}?format=full`); }
  catch (error) { return Response.json({ error: error instanceof Error ? error.message : "Connect Gmail before linking a message", connectUrl: "/api/google/connect" }, { status: 409 }); }
  if (!response.ok) return Response.json({ error: "Gmail could not load this message" }, { status: response.status });
  const message = await response.json() as GmailMessage;
  const headers = new Map(message.payload?.headers?.map(header => [header.name.toLowerCase(), header.value]));
  return Response.json({ id: message.id, subject: headers.get("subject") ?? "(No subject)", sender: headers.get("from") ?? "Unknown sender", receivedAt: message.internalDate ? new Date(Number(message.internalDate)).toISOString() : headers.get("date"), snippet: message.snippet ?? "", html: findBody(message.payload) });
}
