import { desc, eq } from "drizzle-orm";
import { requireAccess } from "../../../access";
import { canUseTask } from "../../../category-access";
import { getDb } from "../../../../db";
import { gmailThreads } from "../../../../db/schema";

function messageIdFrom(value: string) {
  try {
    const url = new URL(value);
    if (url.hostname !== "mail.google.com") return null;
    return url.hash.match(/\/(?:inbox|all|sent|search|label\/[^/]+)\/([a-zA-Z0-9_-]+)/)?.[1] ?? url.hash.match(/#(?:inbox|all|sent)\/([a-zA-Z0-9_-]+)/)?.[1] ?? null;
  } catch { return /^[a-zA-Z0-9_-]{8,}$/.test(value) ? value : null; }
}

export async function GET(request: Request) {
  const access = await requireAccess();
  if (access.error || !access.user) return access.error;
  const taskId = new URL(request.url).searchParams.get("taskId");
  if (!taskId || !await canUseTask(access.user, taskId, "VIEWER")) return Response.json({ error: "Task not found" }, { status: 404 });
  const links = await getDb().select().from(gmailThreads).where(eq(gmailThreads.taskId, taskId)).orderBy(desc(gmailThreads.receivedAt));
  return Response.json({ links });
}

export async function POST(request: Request) {
  const access = await requireAccess();
  if (access.error || !access.user) return access.error;
  const input = await request.json() as { taskId?: string; url?: string; subject?: string; sender?: string; snippet?: string; receivedAt?: string };
  if (!input.taskId || !await canUseTask(access.user, input.taskId, "CONTRIBUTOR")) return Response.json({ error: "You cannot link Gmail to this task" }, { status: 403 });
  const messageId = input.url ? messageIdFrom(input.url) : null;
  if (!messageId || !input.url) return Response.json({ error: "Paste a valid Gmail message link" }, { status: 400 });
  const link = { id: crypto.randomUUID(), messageId, subject: input.subject?.trim() || "Linked Gmail message", sender: input.sender?.trim() || "Gmail", snippet: input.snippet?.trim() || "Open this message in Gmail to view its contents.", bodyHtml: null, gmailUrl: input.url, receivedAt: input.receivedAt ? new Date(input.receivedAt) : new Date(), taskId: input.taskId };
  await getDb().insert(gmailThreads).values(link);
  return Response.json({ link }, { status: 201 });
}

export async function DELETE(request: Request) {
  const access = await requireAccess();
  if (access.error || !access.user) return access.error;
  const id = new URL(request.url).searchParams.get("id");
  if (!id) return Response.json({ error: "Link id is required" }, { status: 400 });
  const linked = await getDb().select({ taskId: gmailThreads.taskId }).from(gmailThreads).where(eq(gmailThreads.id, id)).limit(1);
  if (!linked[0] || !await canUseTask(access.user, linked[0].taskId, "CONTRIBUTOR")) return Response.json({ error: "Linked email not found" }, { status: 404 });
  await getDb().delete(gmailThreads).where(eq(gmailThreads.id, id));
  return Response.json({ ok: true });
}
