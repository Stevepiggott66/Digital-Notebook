CREATE TABLE `allowed_users` (
	`id` text PRIMARY KEY NOT NULL,
	`email` text NOT NULL,
	`role` text DEFAULT 'MEMBER' NOT NULL,
	`is_active` integer DEFAULT true NOT NULL,
	`created_by` text NOT NULL,
	`created_at` integer NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `allowed_users_email_unique` ON `allowed_users` (`email`);--> statement-breakpoint
CREATE INDEX `allowed_users_active_idx` ON `allowed_users` (`is_active`);--> statement-breakpoint
ALTER TABLE `tasks` ADD `parent_id` text REFERENCES tasks(id);--> statement-breakpoint
CREATE INDEX `tasks_parent_idx` ON `tasks` (`parent_id`);