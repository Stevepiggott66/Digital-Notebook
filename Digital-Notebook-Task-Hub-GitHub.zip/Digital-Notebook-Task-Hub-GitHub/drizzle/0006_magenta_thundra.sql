CREATE TABLE `recurring_series` (
	`id` text PRIMARY KEY NOT NULL,
	`title` text NOT NULL,
	`priority` text DEFAULT 'MEDIUM' NOT NULL,
	`recurrence` text NOT NULL,
	`next_occurrence_at` integer NOT NULL,
	`planned_offset_minutes` integer,
	`reminder_offset_minutes` integer,
	`category_id` text,
	`parent_id` text,
	`user_id` text NOT NULL,
	`paused_at` integer,
	`deleted_at` integer,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`category_id`) REFERENCES `categories`(`id`) ON UPDATE no action ON DELETE set null,
	FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `recurring_series_user_idx` ON `recurring_series` (`user_id`);--> statement-breakpoint
CREATE INDEX `recurring_series_next_idx` ON `recurring_series` (`next_occurrence_at`);--> statement-breakpoint
ALTER TABLE `tasks` ADD `series_id` text REFERENCES recurring_series(id) ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE `tasks` ADD `previous_occurrence_id` text REFERENCES tasks(id) ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE `tasks` ADD `occurrence_date` integer;--> statement-breakpoint
CREATE UNIQUE INDEX `tasks_series_occurrence_unique` ON `tasks` (`series_id`,`occurrence_date`);
