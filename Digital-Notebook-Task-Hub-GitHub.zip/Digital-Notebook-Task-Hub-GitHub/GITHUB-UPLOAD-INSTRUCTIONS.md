# Digital Notebook & Task Hub — GitHub upload

This folder contains the complete application source, database schema and migrations, tests, public assets, and deployment configuration.

## Upload through the GitHub website

1. Create a new empty repository on GitHub.
2. Open the repository and choose **Add file → Upload files**.
3. Drag the contents of this folder into the upload area.
4. Add a commit message such as `Initial Digital Notebook import`.
5. Select **Commit changes**.

Do not upload local passwords, API keys, OAuth client secrets, or `.env` files. They have intentionally not been included in this export.

## Run locally

Install Node.js 22 or later and pnpm, then run:

```sh
pnpm install
pnpm dev
```

The application uses OpenAI Sites authentication, D1 database storage, and R2 file storage. A GitHub copy is a source backup; deploying it on a different hosting provider will require equivalent authentication, database, file-storage, and Google OAuth configuration.
